"""Version-checked source repair only. No service, config or runtime writes."""
import argparse,fcntl,hashlib,json,os,shutil,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('project');p.add_argument('--rollback',action='store_true');a=p.parse_args();root=Path(a.project).resolve();source=Path(__file__).resolve().parent;m=json.loads((source/'manifest.json').read_text());backup=root/'code_backups/market_alignment_v1'
state_path=root/'runtime/competition/state.json'
if not state_path.exists():raise SystemExit('Original AWS competition recovery state required')
state=json.loads(state_path.read_text());account=state.get('account_hash')
if not account or state.get('mode')!='COMPETITION':raise SystemExit('Original competition binding required')
locks=Path.home()/'.roostoo-locks';lock_path=locks/(account+'.lock')
if not locks.is_dir():raise SystemExit('Original account lock directory missing')
with open(lock_path,'a') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise SystemExit('Stop the actual runner before installing source repair')
 jobs=[];errors=[]
 for name,info in m.items():
  src=source/name;dest=root/name
  if info['optional'] and not dest.exists():continue
  if dest.is_symlink():errors.append('Refusing symlink '+name);continue
  expected=info['new'] if a.rollback else info['old'];current=hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None
  if not a.rollback and current==info['new']:continue
  if a.rollback and current==info['old']:continue
  if current!=expected:errors.append('Different source version: '+name+' SHA256='+str(current));continue
  if a.rollback:
   replacement=backup/name
   if info['old'] is not None and (not replacement.exists() or hashlib.sha256(replacement.read_bytes()).hexdigest()!=info['old']):errors.append('Missing valid backup '+name)
  else:
   replacement=src
   if hashlib.sha256(src.read_bytes()).hexdigest()!=info['new']:errors.append('Package hash mismatch '+name)
   if name.endswith('.py'):compile(src.read_bytes(),name,'exec')
   existing_backup=backup/name
   if dest.exists() and existing_backup.exists() and hashlib.sha256(existing_backup.read_bytes()).hexdigest()!=info['old']:errors.append('Backup differs '+name)
  jobs.append((name,dest,replacement,info))
 if errors:raise SystemExit('\n'.join(errors))
 for name,dest,replacement,info in jobs:
  if a.rollback and info['old'] is None:
   dest.unlink();continue
  if not a.rollback and dest.exists():
   b=backup/name;b.parent.mkdir(parents=True,exist_ok=True)
   if not b.exists():shutil.copy2(dest,b)
  dest.parent.mkdir(parents=True,exist_ok=True)
  fd,tmp=tempfile.mkstemp(prefix='.alignment-',dir=dest.parent)
  with os.fdopen(fd,'wb') as out:out.write(replacement.read_bytes())
  os.chmod(tmp,0o600);os.replace(tmp,dest)
 print(('Rolled back' if a.rollback else 'Installed')+' '+str(len(jobs))+' source files. Backup: '+str(backup))
 print('State, credentials, config, halt/high water and systemd unchanged. Service NOT started.')
