import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import pandas as pd
from urllib.parse import urlparse,parse_qs
from quant.live import Blocked
from quant.market_alignment import closed_window,align_frames,MarketDataUnavailable
from quant.cross_asset_v2_market import fetch
from quant.cross_asset_v2_engine import market_frames
from quant.hybrid_v3_live_engine import cycle
from quant.hybrid_v3_live_strategy import DEFAULTS
from quant.migrate_hybrid_v3 import digest
from fusion_v4_fixtures import FakeExchange

class AlignmentTests(unittest.TestCase):
 def frame(self,periods=1000,latest='2026-10-05T14:00:00Z'):
  ix=pd.date_range(end=pd.Timestamp(latest),periods=periods,freq='5min')
  return pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.,'volume':100000.},index=ix)
 def actual(self):return dict(account_hash='fake',mode='COMPETITION',hybrid_v3_mode='COMPETITION',config_hash=digest(DEFAULTS),hybrid_v3_config_hash=digest(DEFAULTS),hybrid_v3_verified={'verification':'PASSED_EXECUTION'},intent=None,confirmed_fills=0,hybrid_v3={})
 def test_cutoff_is_one_fixed_closed_bar(self):
  now=int(pd.Timestamp('2026-10-05T14:05:01Z').timestamp()*1000);start,cutoff,latest=closed_window(now)
  self.assertEqual(cutoff,int(pd.Timestamp('2026-10-05T14:05:00Z').timestamp()*1000)-1);self.assertEqual(latest,cutoff//300000*300000);self.assertEqual(latest-start,999*300000)
 def test_trim_earliest_history_only_not_latest(self):
  x=FakeExchange();out=align_frames({'A':self.frame(),'B':self.frame(999)},x.now)
  self.assertEqual(len(out['A']),999);self.assertTrue(out['A'].index.equals(out['B'].index))
 def test_missing_latest_never_backfills_or_uses_old_grid(self):
  with self.assertRaises(MarketDataUnavailable):align_frames({'A':self.frame(),'B':self.frame(latest='2026-10-05T13:55:00Z')},FakeExchange().now)
 def test_internal_gap_rejected(self):
  with self.assertRaises(MarketDataUnavailable):align_frames({'A':self.frame().drop(self.frame().index[-100])},FakeExchange().now)
 def test_insufficient_common_history_rejected(self):
  with self.assertRaises(MarketDataUnavailable):align_frames({'A':self.frame(576)},FakeExchange().now)
 def test_public_fetch_uses_frozen_end_and_start(self):
  f=self.frame();raw=[[int(ix.timestamp()*1000),100,101,99,100,100000,int(ix.timestamp()*1000)+299999] for ix in f.index]
  class Reply:
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def read(self):return json.dumps(raw).encode()
  with patch('quant.cross_asset_v2_market.urlopen',return_value=Reply()) as u:
   out=fetch(['A'],FakeExchange().now)
  query=parse_qs(urlparse(u.call_args.args[0]).query);self.assertEqual(query['endTime'],[str(closed_window(FakeExchange().now)[1])]);self.assertIn('startTime',query);self.assertEqual(len(out['A']),1000)
 def test_network_fault_typed_inside_public_boundary(self):
  with patch('quant.cross_asset_v2_engine.raw_frames',side_effect=TimeoutError('public timeout')):
   with self.assertRaises(MarketDataUnavailable):market_frames(['A'],FakeExchange().now)
 def test_degraded_actual_cycle_blocks_old_normal_targets(self):
  client=FakeExchange();state=self.actual();state['hybrid_v3']['targets']={'BTCUSDT':.05}
  with tempfile.TemporaryDirectory() as d,patch('quant.hybrid_v3_live_engine.market_frames',side_effect=MarketDataUnavailable('missing newest bar')):
   output=cycle(client,state,Path(d),DEFAULTS,False)
  self.assertEqual(output['phase'],'DATA_UNAVAILABLE');self.assertEqual(output['orders'],[]);self.assertFalse(state.get('halted'));self.assertIn('last_checked_utc',state)
 def test_data_fault_cap_reduction_uses_current_holdings_not_stale_zero_target(self):
  client=FakeExchange();state=self.actual();client.balance['SpotWallet']['BTC']={'Free':70.,'Lock':0.};state['hybrid_v3']['targets']={'BTCUSDT':0.}
  with tempfile.TemporaryDirectory() as d,patch('quant.hybrid_v3_live_engine.market_frames',side_effect=MarketDataUnavailable('missing')):output=cycle(client,state,Path(d),DEFAULTS,False)
  self.assertEqual(output['orders'][0]['reason'],'EXPOSURE_CAP_REDUCTION');self.assertLess(output['orders'][0]['estimated_notional'],1301.)
 def test_data_fault_refreshes_quotes_and_keeps_protective_exit(self):
  client=FakeExchange();state=self.actual();client.balance['SpotWallet']['BTC']={'Free':1.,'Lock':0.};state['hybrid_v3']['guards']={'BTCUSDT':{'peak':100.,'stop_price':95.,'stop_fraction':.05}}
  def fault(*a):
   client.ticker['Data']['BTC/USD']={'LastPrice':90.,'MaxBid':89.99,'MinAsk':90.01}
   raise MarketDataUnavailable('network')
  with tempfile.TemporaryDirectory() as d,patch('quant.hybrid_v3_live_engine.market_frames',side_effect=fault):output=cycle(client,state,Path(d),DEFAULTS,False)
  self.assertEqual(output['orders'][0]['reason'],'ATR_PROTECTIVE_EXIT');self.assertEqual(output['orders'][0]['type'],'MARKET')
 def test_ambiguous_order_still_halts(self):
  client=FakeExchange();state=self.actual();state['intent']={'owner':'hybrid_v3','order_id':None}
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(Blocked):cycle(client,state,Path(d),DEFAULTS,False)
  self.assertIsNone(state['intent']['order_id']);self.assertFalse(any(path=='/v3/place_order' for path,_ in client.calls))
if __name__=='__main__':unittest.main()
