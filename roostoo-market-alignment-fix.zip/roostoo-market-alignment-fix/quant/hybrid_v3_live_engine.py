"""Migrated actual hybrid engine; no standalone CLI or implicit activation."""
import argparse,fcntl,hashlib,json,os,time
from pathlib import Path
import pandas as pd
from .live import Blocked,atomic,audit,positive,spot_wallet,short_check
from .roostoo import Roostoo
from .market_alignment import MarketDataUnavailable
from .cross_asset_v2_engine import quote,market_frames
from .cross_asset_v2_execution import quote_ok
from .hybrid_v3_live_strategy import config_load,nav_and_positions,target_weights,protective_exits,finish_exits
from .hybrid_v3_live_orders import save,reconcile,pending_guard,cancel,submit,plan_orders


def reservations(balance,state):
 wallet=spot_wallet(balance);intent=state.get('intent')
 for coin,item in wallet.items():
  locked=positive(item.get('Lock',0),'lock',True)
  if locked<=1e-8:continue
  if not intent or intent.get('owner')!='hybrid_v3' or intent.get('order_id') is None:raise Blocked('Unowned balance reservation; do not reset state')
  allowed='USD' if intent['side']=='BUY' else intent['pair'].split('/')[0]
  maximum=float(intent['quantity'])*(float(intent.get('price',0))*1.002 if allowed=='USD' else 1.)
  if coin!=allowed or locked>maximum+max(1e-8,maximum*1e-6):raise Blocked('Reservation differs from owned limit order')


def new_signals(client,exchange,ticker,balance,state,c):
 active=[];_,_,units=nav_and_positions(balance,ticker,c['symbols'])
 for s in c['symbols']:
  if quote_ok(s,exchange,ticker,c):active.append(s)
  elif units.get(s,0)>1e-8:raise Blocked('Held quote invalid for normal signal; risk stop remains separate')
 if not active:raise Blocked('No healthy cross-asset quotes')
 frames=market_frames(active,int(ticker['ServerTime']));fresh=quote(client)
 for s in list(frames):
  f=frames[s];age=pd.to_datetime(int(fresh['ServerTime']),unit='ms',utc=True)-(f.index[-1]+pd.Timedelta('5min'))
  if age<pd.Timedelta(0) or age>pd.Timedelta('7min'):raise Blocked('Closed five-minute data stale after download')
  if abs(float(fresh['Data'][s[:-4]+'/USD']['LastPrice'])/float(f.close.iloc[-1])-1)>c['max_basis']:
   if units.get(s,0)>1e-8:raise Blocked('Held asset public/execution price mismatch')
   del frames[s]
 if not frames:raise Blocked('No basis-aligned frames')
 weights,decisions,bar=target_weights(frames,balance,fresh,state,c,int(client.timestamp()))
 audit(Path(state['_directory']),'hybrid_signal',bar=bar,weights=weights,decisions=decisions)
 return fresh


def cycle(client,state,directory,c,execute=False):
 client.sync_time()
 if abs(float(client.offset))>60000:raise Blocked('Host clock differs from exchange by >60 seconds')
 state['_directory']=str(directory)
 reconcile(client,state,directory);pending_guard(client,state);short_check(client)
 exchange=client.request('/v3/exchangeInfo');ticker=quote(client);balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True)
 reservations(balance,state)
 signals_ready=True;data_error=None
 now=int(client.timestamp());nav,values,units=nav_and_positions(balance,ticker,c['symbols']);h=state.setdefault('hybrid_v3',{})
 h.setdefault('activation_nav',nav);h.setdefault('activation_ms',now)
 state['high_water']=max(nav,float(state.get('high_water',nav)));drawdown=nav/state['high_water']-1
 if (Path(directory)/'STOP').exists() or drawdown<=-c['drawdown_stop']:state['halted']=True
 forced=protective_exits(state,ticker,units,c,now)
 started=now>=int(pd.Timestamp(c['start_utc']).timestamp()*1000)
 risk=bool(state.get('halted') or any(v['reason']=='ATR_PROTECTIVE_EXIT' for v in forced.values()))
 # Risk evaluation precedes public data fetch and operates on persisted stops.
 overdue_exit=any(now-v['since_ms']>=c['exit_deadline_seconds']*1000 for v in forced.values())
 if not risk and not overdue_exit:
  expected=(int(ticker['ServerTime'])//300000-1)*300000
  if h.get('signal_bar')!=expected:
   try:ticker=new_signals(client,exchange,ticker,balance,state,c)
   except MarketDataUnavailable as e:
    signals_ready=False;data_error=str(e)
    # Preserve all state. Cancel only a known owned ordinary order; any
    # uncertain cancellation is fatal and prevents replacement submission.
    old_intent=state.get('intent')
    if execute and old_intent and old_intent.get('owner')=='hybrid_v3' and (old_intent['side']=='BUY' or old_intent.get('reason')=='TARGET_REBALANCE'):
     cancel(client,state,directory,True,'SIGNAL_DATA_UNAVAILABLE')
     pending_guard(client,state)
    balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True);ticker=quote(client)
    reservations(balance,state)
    audit(directory,'public_data_unavailable',detail=data_error,new_entries_blocked=True)
   except Exception:
    # With no usable signal, do not leave a known BUY live. Cancel only in execute mode.
    if execute and state.get('intent') and state['intent'].get('owner')=='hybrid_v3' and state['intent']['side']=='BUY':cancel(client,state,directory,True,'SIGNAL_DATA_UNAVAILABLE')
    raise
  now=int(client.timestamp());nav,values,units=nav_and_positions(balance,ticker,c['symbols'])
  state['high_water']=max(nav,state['high_water']);drawdown=nav/state['high_water']-1
  if drawdown<=-c['drawdown_stop']:state['halted']=True
  forced=protective_exits(state,ticker,units,c,now)
 risk=bool(state.get('halted') or any(v['reason']=='ATR_PROTECTIVE_EXIT' for v in forced.values()))
 weights=dict(h.get('targets',{}))
 if not signals_ready:weights={s:values.get(s,0)/nav for s in c['symbols']}
 if state.get('halted'):weights={s:0. for s in c['symbols']}
 else:
  for s in forced:weights[s]=0.
 # Only one live order; cancellation uses terminal exchange confirmation.
 intent=state.get('intent');would_cancel=None
 if intent:
  if intent.get('owner')!='hybrid_v3':raise Blocked('Legacy order unresolved')
  s=intent['pair'].split('/')[0]+'USDT';desired=weights.get(s,0)*nav;held=values.get(s,0)
  deadline=s in forced and now-forced[s]['since_ms']>=c['exit_deadline_seconds']*1000
  if not signals_ready and (intent['side']=='BUY' or intent.get('reason')=='TARGET_REBALANCE'):would_cancel='SIGNAL_DATA_UNAVAILABLE'
  elif state.get('halted') or risk:would_cancel='RISK_REPLAN'
  elif intent.get('cancel_attempted'):would_cancel='UNCONFIRMED_CANCEL'
  elif deadline:would_cancel='EXIT_DEADLINE'
  elif now-intent['submitted_ms']>=c['limit_ttl_seconds']*1000:would_cancel='LIMIT_EXPIRED'
  elif intent['side']=='BUY' and (s in forced or desired<=held):would_cancel='BUY_SIGNAL_OR_TARGET_INVALID'
  elif intent['side']=='SELL' and s not in forced and desired>=held:would_cancel='SELL_TARGET_INVALID'
  elif s not in forced:
   remainder=float(intent.get('remaining_quantity',intent['quantity']))*float(intent.get('price',ticker['Data'][intent['pair']]['LastPrice']))
   band=max(c['min_trade_usd'],min(nav*c['band_weight'],c['test_band_usd']))
   if remainder>abs(desired-held)+band:would_cancel='REMAINING_ORDER_EXCEEDS_TARGET'
  if would_cancel and execute:
   h.setdefault('expired_pairs',{})[intent['pair']]=h.get('signal_bar') if would_cancel=='LIMIT_EXPIRED' else None
   cancel(client,state,directory,True,would_cancel)
   pending_guard(client,state)
   balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True);ticker=quote(client)
   reservations(balance,state);nav,values,units=nav_and_positions(balance,ticker,c['symbols']);now=int(client.timestamp())
 if not state.get('intent'):finish_exits(state,units,exchange,ticker,c,now)
 _,orders=plan_orders(exchange,ticker,balance,weights,state,c,now)
 if not signals_ready:orders=[o for o in orders if o['side']=='SELL' and o['reason']!='TARGET_REBALANCE']
 bar=h.get('signal_bar');count=h.get('bar_count',{}) if h.get('trade_bar')==bar else {}
 emergency=bool(state.get('halted') or h.get('forced_exit'))
 eligible=started and (emergency or (count.get('count',0)<c['max_orders_per_bar'] and count.get('notional',0)<c['max_new_notional_per_bar']))
 if state.get('intent'):eligible=False
 orders=[o for o in orders if o['side']=='SELL' and o['reason']!='TARGET_REBALANCE' or (h.get('expired_pairs',{}).get(o['pair'])!=bar and o['pair'] not in count.get('pairs',[]))]
 # Risk exits never share an execution batch with new entries.
 if h.get('forced_exit') or state.get('halted'):orders=[o for o in orders if o['side']=='SELL']
 if execute and eligible and orders:
  order=orders[0]
  # Immediate freshness and balance checks; regenerate amount, never use old cash.
  fresh=quote(client);current=client.request('/v3/balance',{'timestamp':client.timestamp()},True)
  current_nav,_,current_units=nav_and_positions(current,fresh,c['symbols']);state['high_water']=max(state['high_water'],current_nav)
  if current_nav/state['high_water']-1<=-c['drawdown_stop']:state['halted']=True
  protective_exits(state,fresh,current_units,c,int(client.timestamp()))
  _,new=plan_orders(exchange,fresh,current,weights,state,c,int(client.timestamp()))
  if not signals_ready:new=[o for o in new if o['side']=='SELL' and o['reason']!='TARGET_REBALANCE']
  same=[o for o in new if o['pair']==order['pair'] and o['side']==order['side']]
  if same:
   order=same[0]
   if not emergency:
    remaining=c['max_new_notional_per_bar']-count.get('notional',0)
    if order['estimated_notional']>remaining+1e-8:order=None
   if order:
    if order['side']=='BUY':
     s=order['pair'].split('/')[0]+'USDT';mark=positive(fresh['Data'][order['pair']]['LastPrice'],'entry risk mark')
     fraction=max(c['stop_floor'],min(c['stop_ceiling'],c['stop_atr']*h.get('atr_fractions',{}).get(s,c['stop_floor']/c['stop_atr'])))
     h.setdefault('guards',{}).setdefault(s,{'peak':mark,'stop_price':mark*(1-fraction),'stop_fraction':fraction,'origin':'first_entry_submission'})
    h['trade_bar']=bar;count={'count':count.get('count',0)+1,'notional':count.get('notional',0)+order['estimated_notional'],'pairs':count.get('pairs',[])+[order['pair']]};h['bar_count']=count
    h.setdefault('last_submit',{})[order['pair']]=int(client.timestamp());save(directory,state)
    pending_guard(client,state);submit(client,state,directory,order,c,True)
    balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True);ticker=quote(client)
    pending_guard(client,state);reservations(balance,state)
    nav,values,units=nav_and_positions(balance,ticker,c['symbols'])
 state.update(last_nav=nav,last_phase='RISK_EXIT' if state.get('halted') else 'READY' if signals_ready else 'DATA_UNAVAILABLE',last_checked_utc=pd.Timestamp.now(tz='UTC').isoformat())
 save(directory,state)
 i=state.get('intent');summary={'mode':'HYBRID_V3_COMPETITION_EXECUTE' if execute else 'HYBRID_V3_COMPETITION_DRY_RUN','phase':state['last_phase'],'data_ready':signals_ready,'data_error':data_error,'nav':round(nav,2),'drawdown':round(nav/state['high_water']-1,6),'orders':orders[:4],'eligible_now':eligible,'pending_order':None if not i else {'order_id':i.get('order_id'),'pair':i['pair'],'side':i['side'],'type':i['type'],'remaining_quantity':i.get('remaining_quantity')},'would_cancel':would_cancel,'candidate_fees_usd':round(h.get('fees_usd',0),6),'candidate_turnover_usd':round(h.get('filled_notional',0),2),'confirmed_fills':state.get('confirmed_fills',0),'forced_exits':h.get('forced_exit',{}),'signal_bar':bar,'test_only':False}
 audit(directory,'hybrid_cycle',**summary);print(json.dumps(summary),flush=True)
 return summary

