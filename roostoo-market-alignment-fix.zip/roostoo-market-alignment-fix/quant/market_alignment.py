"""Strict alignment at a single exchange-time closed bar; no synthesized prices."""
import pandas as pd
from .live import Blocked
STEP_MS=300000
class MarketDataUnavailable(Blocked):
    """Public data fault only; never used for order/account errors."""

def closed_window(now_ms,limit=1000):
    cutoff=int(now_ms)//STEP_MS*STEP_MS-1
    latest=cutoff//STEP_MS*STEP_MS
    return latest-(limit-1)*STEP_MS,cutoff,latest

def align_frames(frames,now_ms):
    if not frames:raise MarketDataUnavailable('No public candle frames')
    latest=pd.to_datetime(closed_window(now_ms)[2],unit='ms',utc=True)
    starts=[]
    for symbol,f in frames.items():
        if len(f)<577 or not isinstance(f.index,pd.DatetimeIndex) or f.index.tz is None:
            raise MarketDataUnavailable('Insufficient dated candles: '+symbol)
        if not f.index.is_unique or not f.index.is_monotonic_increasing:
            raise MarketDataUnavailable('Duplicate/unsorted candles: '+symbol)
        if f.index[-1]!=latest:
            raise MarketDataUnavailable('Latest closed candle missing: '+symbol)
        if not (f.index.to_series().diff().dropna()==pd.Timedelta('5min')).all():
            raise MarketDataUnavailable('Missing or wrong-interval candles: '+symbol)
        starts.append(f.index[0])
    start=max(starts)
    expected=pd.date_range(start=start,end=latest,freq='5min')
    if len(expected)<577:raise MarketDataUnavailable('Common candle history shorter than 577 bars')
    out={s:f.loc[start:latest].copy() for s,f in frames.items()}
    if not all(f.index.equals(expected) for f in out.values()):
        raise MarketDataUnavailable('Common five-minute grid is incomplete')
    return out
