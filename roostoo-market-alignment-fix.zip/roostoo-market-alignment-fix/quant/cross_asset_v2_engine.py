"""Isolated TEST engine; production competition module is unchanged."""
import json,os,hashlib
from pathlib import Path
from dataclasses import replace
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from .live import Blocked,Limits,atomic,audit,positive,spot_wallet,plan,pending_check,short_check,recover,submit
from .strategy import Config,targets
from .cross_asset_v2_market import fetch as raw_frames

def market_frames(symbols,now):
    from .market_alignment import align_frames,MarketDataUnavailable
    try:
        with ThreadPoolExecutor(max_workers=6) as pool:
            parts=list(pool.map(lambda s:raw_frames([s],now),symbols))
    except (Blocked,OSError,ValueError,KeyError,IndexError,TypeError) as e:
        # Only exceptions inside the PUBLIC candle-fetch boundary are retryable.
        # Account/order calls are outside this boundary and must still halt.
        raise MarketDataUnavailable('Public candle request unavailable: '+type(e).__name__) from e
    return align_frames({s:p[s] for s,p in zip(symbols,parts)},now)


SYMBOLS=["BTCUSDT","ETHUSDT","SOLUSDT"]

def gate(client,c):
    now=int(client.timestamp())
    # sync_time uses trusted exchange time, not user-local scheduling.
    return now>=int(pd.Timestamp(c['start_utc']).timestamp()*1000)


def quote(client):
    result=client.request('/v3/ticker',{'timestamp':client.timestamp()})
    if result.get('Success') is not True or abs(int(result.get('ServerTime',0))-int(client.timestamp()))>15000:raise Blocked('Roostoo ticker stale or invalid')
    return result


def valuation(balance,ticker,symbols=None):
    symbols=SYMBOLS if symbols is None else symbols
    wallet=spot_wallet(balance);nav=positive(wallet['USD'].get('Free',0),'cash',True)
    # Locked/reserved sums are not added twice or silently omitted from NAV:
    # while account has locks the runner stops until reconciliation resolves them.
    for coin,entry in wallet.items():
        if any(positive(entry.get(k,0),k,True)>1e-8 for k in ('Lock','PendingOrders','ShortCollateral')):raise Blocked('Account reserved funds require reconciliation')
        free=positive(entry.get('Free',0),'coin units',True)
        if coin=='USD':continue
        if coin+'USDT' not in symbols and free>1e-8:raise Blocked('Unsupported account asset')
        if free:nav+=free*positive(ticker['Data'][coin+'/USD']['LastPrice'],'valuation price')
    if nav<=0:raise Blocked('Empty competition account')
    return nav


def limits(c):
    return Limits(coin_cap=float(c['coin_cap']),gross_cap=float(c['gross_cap']),
                  cash_reserve=1-float(c['gross_cap']),min_trade_usd=float(c['min_trade_usd']),
                  band_weight=float(c['band_weight']),band_usd_cap=float('inf'),
                  max_spread=float(c['max_spread']),max_basis=float(c['max_basis']))



def execute_guarded(client,state,directory,order,c,execute):
    mode='COMPETITION' if c['strategy_version']=='cross_asset_v2_competition' else 'TEST'
    if not execute or os.getenv('ROOSTOO_ACCOUNT_MODE')!=mode or state.get('cross_asset_v2_mode')!=mode:
        raise Blocked('Cross-asset execution requires bound TEST profile')
    if mode=='COMPETITION' and (state.get('mode')!='COMPETITION' or not state.get('cross_asset_v2_verified') or state.get('config_hash')!=hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()):
        raise Blocked('Actual execution requires verified explicit migration')
    if not gate(client,c):raise Blocked('Start gate not open')
    if state.get('halted') and order['side']!='SELL':raise Blocked('Risk exit only permits sells')
    submit(client,state,directory,order)

def cycle(client,state,directory,c,execute=False):
    symbols=c.get('symbols',SYMBOLS)
    client.sync_time()
    if abs(float(client.offset))>60000:raise Blocked('Host clock differs from exchange by >60 seconds')
    recover(client,state,directory);pending_check(client);short_check(client)
    exchange=client.request('/v3/exchangeInfo')
    ticker=quote(client);balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True)
    nav=valuation(balance,ticker,symbols)
    started=gate(client,c)
    state['high_water']=max(nav,float(state.get('high_water',nav)))
    drawdown=nav/state['high_water']-1
    if started and drawdown<=-float(c['drawdown_stop']):state['halted']=True
    halted=bool(state.get('halted',False));weights={s:0.0 for s in symbols};bar=None
    if halted:
        # Independent of Binance availability when exiting risk. Avoid applying
        # entry spread/basis filters to an emergency sell. No stale-price orders.
        frames={s:pd.DataFrame({'close':[positive(ticker['Data'][s[:-4]+'/USD']['LastPrice'],'exit quote')]}) for s in symbols if positive(spot_wallet(balance).get(s[:-4],{}).get('Free',0),'exit units',True)>0}
        weights={s:0.0 for s in frames}
    else:
        if 'symbols' in c:
            from .cross_asset_v2_execution import select_symbols
            active=select_symbols(symbols,exchange,ticker,balance,c)
        else:active=symbols
        frames=market_frames(active,int(ticker['ServerTime']))
        ticker=quote(client)
        nav=valuation(balance,ticker,symbols)
        c_signal=replace(Config(),coin_cap=float(c['coin_cap']),gross_cap=float(c['gross_cap']))
        if 'symbols' in c:
            from .cross_asset_v2_execution import execution_weights as expanded_weights
            weights=expanded_weights(frames,exchange,ticker,balance,c)
        else:weights=targets(frames,c_signal).iloc[-1].to_dict()
        bar=int(next(iter(frames.values())).index[-1].timestamp()*1000)
        audit(directory,'signal_diagnostics',bar=bar,decisions={s:f.attrs.get('decision',{}) for s,f in frames.items()},targets=weights)
    if 'symbols' in c:
        from .cross_asset_v2_execution import execution_plan as exit_plan
        planner=exit_plan
    else:planner=plan
    _,orders=planner(exchange,ticker,balance,weights,frames,float(c['max_order_usd']),limits(c),halted)
    if 'symbols' in c:
        audit(directory,'universe_selection',candidates=list(frames),selected=[s for s,w in weights.items() if w>0],weights=weights,held=[coin for coin,v in spot_wallet(balance).items() if coin!='USD' and float(v.get('Free',0))>0])
    phase='RISK_EXIT' if halted else ('READY' if started else 'WAITING_START')
    eligible=started and (halted or (bar//300000%int(c['rebalance_bars'])==0 and state.get('last_bar')!=bar))
    state.update(last_nav=nav,last_phase=phase,last_checked_utc=pd.Timestamp.now(tz='UTC').isoformat())
    atomic(Path(directory)/'state.json',state)
    summary={'mode':('CROSS_ASSET_V2_'+('COMPETITION' if c['strategy_version']=='cross_asset_v2_competition' else 'TEST')+('_EXECUTE' if execute else '_DRY_RUN')),'phase':phase,'nav':round(nav,2),'drawdown':round(drawdown,6),'orders':orders,'eligible_now':eligible,'start_utc':c['start_utc'],'confirmed_fills':state.get('confirmed_fills',0),'active_days':len(state.get('active_days',[]))}
    audit(directory,'cycle',**summary,weights=weights);print(json.dumps(summary),flush=True)
    if not execute or not eligible:return
    if not halted:
        state['last_bar']=bar;atomic(Path(directory)/'state.json',state)
    for order in orders:
        pending_check(client);short_check(client)
        fresh=quote(client);current=client.request('/v3/balance',{'timestamp':client.timestamp()},True)
        # Re-check risk immediately before every submit; drawdown may have changed
        # after a fill or during a long API response.
        latest_nav=valuation(current,fresh,symbols)
        state['high_water']=max(latest_nav,state['high_water'])
        if latest_nav/state['high_water']-1<=-float(c['drawdown_stop']):state['halted']=True
        risk_exit=bool(state.get('halted'));new_weights={s:0 for s in frames} if risk_exit else weights
        _,new_orders=planner(exchange,fresh,current,new_weights,frames,float(c['max_order_usd']),limits(c),risk_exit)
        same=[o for o in new_orders if o['pair']==order['pair'] and o['side']==('SELL' if risk_exit else order['side'])]
        atomic(Path(directory)/'state.json',state)
        if same:execute_guarded(client,state,directory,same[0],c,execute)
    # Pull confirmed wallet after the complete batch, do not infer holdings from
    # order quantities (coin-vs-USD fees may differ).
    after=client.request('/v3/balance',{'timestamp':client.timestamp()},True)
    after_nav=valuation(after,quote(client),symbols);state['last_nav']=after_nav
    atomic(Path(directory)/'state.json',state);audit(directory,'post_batch_nav',nav=after_nav)
