"""Closed five-minute public candles; never substitutes 15-minute data."""
import json
from urllib.parse import urlencode
from urllib.request import urlopen
import pandas as pd
from .live import Blocked,positive
from .market_alignment import closed_window,align_frames,MarketDataUnavailable

def fetch(symbols,now_ms):
    frames={}
    start_ms,cutoff_ms,latest_ms=closed_window(now_ms)
    for symbol in symbols:
        query=urlencode({'symbol':symbol,'interval':'5m','limit':1000,'startTime':start_ms,'endTime':cutoff_ms})
        with urlopen('https://data-api.binance.vision/api/v3/klines?'+query,timeout=15) as response:raw=json.load(response)
        if not isinstance(raw,list):raise Blocked('Invalid five-minute response')
        rows=[]
        for bar in raw:
            if int(bar[6])>cutoff_ms:continue
            if not start_ms<=int(bar[0])<=latest_ms:continue
            rows.append({'timestamp':pd.to_datetime(int(bar[0]),unit='ms',utc=True),**{name:positive(bar[pos],name,name=='volume') for name,pos in [('open',1),('high',2),('low',3),('close',4),('volume',5)]}})
        if len(rows)<577:raise Blocked('Need at least 577 closed five-minute candles')
        f=pd.DataFrame(rows).set_index('timestamp').sort_index()
        if f.index.has_duplicates or not (f.index.to_series().diff().dropna()==pd.Timedelta('5min')).all():raise Blocked('Five-minute candles duplicated/missing/wrong interval')
        if ((f.high<f[['open','close','low']].max(axis=1))|(f.low>f[['open','close','high']].min(axis=1))).any():raise Blocked('Invalid five-minute OHLC')
        age=pd.to_datetime(now_ms,unit='ms',utc=True)-(f.index[-1]+pd.Timedelta('5min'))
        if age<pd.Timedelta(0) or age>pd.Timedelta('7min'):raise Blocked('Stale five-minute candle')
        frames[symbol]=f
    return align_frames(frames,now_ms)
