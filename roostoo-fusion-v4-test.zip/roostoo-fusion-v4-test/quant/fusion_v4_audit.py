"""Local read-only pairing of available V3 fills; not whole-account attribution."""
import argparse,json,math
from collections import defaultdict,deque
from pathlib import Path

def analyze(state):
 fills=state.get('hybrid_v3',{}).get('fills',[]);lots=defaultdict(deque);pairs=defaultdict(lambda:{'matched_gross_pnl':0.,'matched_fees':0.,'matched_net_pnl':0.,'matched_sell_updates':0,'losing_sell_updates':0,'unmatched_sold_quantity':0.,'quick_losing_net_pnl':0.});closed=[];fees=turnover=0.;warnings=[]
 unsupported={f['pair'] for f in fills if f.get('commission_coin','USD')!='USD' and float(f.get('fee_native',0))!=0}
 for f in sorted(fills,key=lambda f:int(f.get('observed_ms',0))):
  pair=f['pair'];q=float(f['quantity_delta']);n=float(f['notional_delta']);fee=float(f.get('fee_usd',0));time=int(f.get('observed_ms',0))
  if not all(math.isfinite(v) and v>=0 for v in [q,n,fee]):raise ValueError('Invalid persisted fill')
  fees+=fee;turnover+=n
  if pair in unsupported:continue
  if q<=1e-10:
   if fee:warnings.append('Fee-only adjustment not assigned to lots: '+str(f['order_id']))
   continue
  price=n/q
  if f['side']=='BUY':lots[pair].append({'q':q,'price':price,'fee_per_unit':fee/q,'ms':time,'order_id':f['order_id']});continue
  if f['side']!='SELL':raise ValueError('Unsupported side')
  remaining=q;gross=matched_fee=matched=quick=0.;legs=[]
  while remaining>1e-10 and lots[pair]:
   lot=lots[pair][0];take=min(remaining,lot['q']);g=take*(price-lot['price']);cost=take*(fee/q+lot['fee_per_unit']);net=g-cost;duration=(time-lot['ms'])/60000
   if duration<60 and net<0:quick+=net
   legs.append({'buy_order_id':lot['order_id'],'quantity':take,'buy_price':lot['price'],'sell_price':price,'net_pnl':net,'observed_minutes':duration})
   gross+=g;matched_fee+=cost;matched+=take;remaining-=take;lot['q']-=take
   if lot['q']<=1e-10:lots[pair].popleft()
  p=pairs[pair];p['unmatched_sold_quantity']+=remaining
  if matched:
   net=gross-matched_fee;p['matched_gross_pnl']+=gross;p['matched_fees']+=matched_fee;p['matched_net_pnl']+=net;p['matched_sell_updates']+=1;p['losing_sell_updates']+=int(net<0);p['quick_losing_net_pnl']+=quick
   closed.append({'pair':pair,'sell_order_id':f['order_id'],'reason':f.get('reason'),'quantity':matched,'gross_pnl':gross,'fees':matched_fee,'net_pnl':net,'legs':legs})
 nav=state.get('last_nav');high=state.get('high_water');by_reason=defaultdict(lambda:{'matched_net_pnl':0.,'sell_updates':0})
 for x in closed:by_reason[x['reason']]['matched_net_pnl']+=x['net_pnl'];by_reason[x['reason']]['sell_updates']+=1
 return {'mode':'LOCAL_FILL_AUDIT','last_checked_utc':state.get('last_checked_utc'),'nav':nav,'drawdown':nav/high-1 if nav is not None and high else None,'halted':state.get('halted',False),'pending_intent':bool(state.get('intent')),'available_fill_updates':len(fills),'fees_usd':fees,'turnover_usd':turnover,'matched_gross_pnl':sum(p['matched_gross_pnl'] for p in pairs.values()),'matched_net_pnl':sum(p['matched_net_pnl'] for p in pairs.values()),'by_pair':dict(pairs),'by_exit_reason':dict(by_reason),'unsupported_base_fee_pairs':sorted(unsupported),'warnings':warnings,'scope':'FIFO pairing within available V3 records only. Inherited cost and missing earlier fills are unknown; this is not whole-account loss attribution. Observed times are reconciliation times. No slippage attribution without submission quotes.','closed_pairs':closed}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--state',default='runtime/competition/state.json');p.add_argument('--output',default='reports/current_fill_audit.json');a=p.parse_args();result=analyze(json.loads(Path(a.state).read_text()));dest=Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,indent=2));summary={k:v for k,v in result.items() if k!='closed_pairs'};print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
