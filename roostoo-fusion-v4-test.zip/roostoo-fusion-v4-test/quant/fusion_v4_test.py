"""Dedicated TEST runner. No actual-account or systemd activation capability."""
import argparse,fcntl,hashlib,json,os,time
from pathlib import Path
from .live import Blocked,atomic
from .roostoo import Roostoo
from .cross_asset_v2_test import load_profile
from .fusion_v4_strategy import DEFAULTS,config_load,digest,nav_and_positions
from .fusion_v4_orders import save,reconcile,pending_guard,cancel
from .fusion_v4_engine import cycle
from .cross_asset_v2_engine import quote

def bind(state,account,c):
 if state.get('account_hash')!=account or state.get('mode')=='COMPETITION' or state.get('hybrid_v3_mode')!='TEST':raise Blocked('Existing Hybrid TEST account state required')
 if state.get('intent'):raise Blocked('Resolve existing owned TEST order before candidate activation')
 if state.get('fusion_v4_config_hash') not in (None,digest(c)):raise Blocked('Do not change registered candidate or reset recovery state')
 state['fusion_v4_mode']='TEST';state['fusion_v4_config_hash']=digest(c)
 v=state.setdefault('fusion_v4',{});v.setdefault('fill_cursor',len(state.get('hybrid_v3',{}).get('fills',[])))
 # Existing holdings have unknown acquisition cost; do not fabricate a basis.
 return state

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--profile',default='runtime/test/credentials.json');p.add_argument('--state-dir',default='runtime/test');p.add_argument('--config',default='fusion.v4.test.json');p.add_argument('--bind-candidate',action='store_true');p.add_argument('--execute-test',action='store_true');p.add_argument('--once',action='store_true');p.add_argument('--cancel-owned',action='store_true');a=p.parse_args();c=config_load(a.config);profile=load_profile(a.profile);directory=Path(a.state_dir).resolve();os.umask(0o077)
 account=hashlib.sha256(profile['api_key'].encode()).hexdigest();locks=Path.home()/'.roostoo-locks';locks.mkdir(mode=0o700,exist_ok=True)
 os.environ['ROOSTOO_API_KEY']=profile['api_key'];os.environ['ROOSTOO_SECRET_KEY']=profile['secret'];os.environ['ROOSTOO_ACCOUNT_MODE']='TEST'
 with open(locks/(account+'.lock'),'a') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise Blocked('Stop the existing TEST runner first; actual service is independent')
  bound=locks/(account+'.json')
  if not bound.exists() or json.loads(bound.read_text()).get('state_dir')!=str(directory):raise Blocked('Original bound TEST directory required')
  state=json.loads((directory/'state.json').read_text())
  if a.bind_candidate:
   if a.execute_test or a.cancel_owned:raise Blocked('Binding must be a separate command without execution')
   if not state.get('fusion_v4_config_hash'):atomic(directory/'state.before_fusion_v4.json',state)
   bind(state,account,c)
   proof=directory/'verification.hybrid_v3.json'
   if proof.exists():
    archive=directory/'verification.hybrid_v3.before_fusion_v4.json'
    if archive.exists():raise Blocked('Prior proof archive already exists; inspect instead of overwriting')
    proof.rename(archive)
   client=Roostoo();client.sync_time();pending_guard(client,state)
   balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True);ticker=quote(client)
   _,_,units=nav_and_positions(balance,ticker,c['symbols'])
   for symbol,q in units.items():
    state['fusion_v4'].setdefault('positions',{}).setdefault(symbol,{'kind':'inherited','quantity':q,'basis_known':False})
   state['hybrid_v3']['signal_bar']=None
   save(directory,state);print('Fusion TEST bound. History, halt, high water and old strategy hash retained. No order submitted.');return
  if state.get('account_hash')!=account or state.get('mode')=='COMPETITION' or state.get('fusion_v4_mode')!='TEST' or state.get('fusion_v4_config_hash')!=digest(c):raise Blocked('Run --bind-candidate with the existing TEST account first')
  client=Roostoo()
  if a.cancel_owned:
   client.sync_time();reconcile(client,state,directory);pending_guard(client,state)
   if state.get('intent'):cancel(client,state,directory,True,'MANUAL_TEST_STOP')
   print('Known owned TEST order terminal or absent.');return
  while True:
   cycle(client,state,directory,c,a.execute_test)
   if a.once:return
   time.sleep(c['poll_seconds'])
if __name__=='__main__':
 try:main()
 except KeyboardInterrupt:print('Stopped; recovery state retained. Resolve any owned pending TEST order before switching runners.')
 except Blocked as e:raise SystemExit('Stopped safely: '+str(e))
