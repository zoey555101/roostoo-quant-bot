"""Fixed unoptimized TEST candidate: pullback trend + restricted mean reversion."""
import copy,json,hashlib,math
from pathlib import Path
import numpy as np
import pandas as pd
from .live import Blocked,positive
from .hybrid_v3_strategy import DEFAULTS as V3,atr,nav_and_positions,cap_weights,protective_exits,finish_exits as original_finish,target_weights as original_targets
from .cross_asset_v2_risk import risk_budget
DEFAULTS=copy.deepcopy(V3)
DEFAULTS.update(strategy_version='fusion_v4_test',cooldown_bars=12,config_note='TEST ONLY fixed hypothesis. No profit validation; no actual runner.')
DEFAULTS['fusion']={'trend_cap':.5,'mean_cap':.1,'mean_asset_cap':.03,'entry_atr_min':-.5,'entry_atr_max':1.,'range_gap_atr':.5,'range_slope_atr':.35,'range_momentum_atr':2.,'range_momentum_floor':.005,'mean_window':48,'mean_z_entry':-1.5,'mean_z_ceiling':-.5,'mean_max_hold_bars':24,'net_room_margin':.002,'ordinary_profit_margin':.001}

def digest(c):return hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()
def config_load(path):
 c=json.loads(Path(path).read_text())
 if c!=DEFAULTS:raise Blocked('Fixed fusion.v4.test.json required')
 return c

def signal(frame,quote,c):
 if len(frame)<577 or not frame.index.is_unique or not (frame.index.to_series().diff().dropna()==pd.Timedelta('5min')).all():raise Blocked('577+ aligned closed five-minute bars required')
 p=c['fusion'];close=frame.close;fast=close.ewm(span=60,adjust=False,min_periods=150).mean();slow=close.ewm(span=150,adjust=False,min_periods=150).mean();a=atr(frame,c['atr_bars']);mom=close.pct_change(288,fill_method=None);gap=(fast-slow)/a;location=(close-fast)/a;mean=close.rolling(p['mean_window']).mean();std=close.rolling(p['mean_window']).std();z=(close-mean)/std
 liquid=bool(((close*frame.volume).rolling(288).sum().iloc[-2:]>=5000000).all() and (frame.volume.iloc[-2:]>0).all());bounce=bool((close.diff().iloc[-2:]>0).all());ap=float(a.iloc[-1]/close.iloc[-1]);m=float(mom.iloc[-1]);g=float(gap.iloc[-1]);slope=float((slow.iloc[-1]-slow.iloc[-13])/a.iloc[-1]);loc=float(location.iloc[-1]);spread=(float(quote['MinAsk'])-float(quote['MaxBid']))/float(quote['LastPrice'])
 values=[ap,m,g,slope,loc,spread,float(mean.iloc[-1]),float(mean.iloc[-1])]
 if not all(math.isfinite(x) for x in values) or ap<=0 or spread<0:raise Blocked('Invalid fusion signal')
 trend=liquid and bounce and bool(((mom.iloc[-2:]>c['signal_buffer_atr']*(a/close).iloc[-2:]) & (gap.iloc[-2:]>c['signal_buffer_atr'])).all()) and p['entry_atr_min']<=loc<=p['entry_atr_max']
 sideways=liquid and abs(g)<=p['range_gap_atr'] and abs(slope)<=p['range_slope_atr'] and abs(m)<=max(p['range_momentum_floor'],p['range_momentum_atr']*ap)
 room=float(mean.iloc[-1]/float(quote['MinAsk'])-1);cost_room=2*c['taker_fee']+2*spread+p['net_room_margin']
 mean_entry=sideways and bounce and float(z.iloc[-3])<p['mean_z_entry'] and float(z.iloc[-1])<p['mean_z_ceiling'] and math.isfinite(float(z.iloc[-1])) and room>cost_room and spread<=c['max_spread']
 return {'trend_entry':bool(trend),'mean_entry':bool(mean_entry),'sideways':bool(sideways),'location_atr':loc,'ema_fast':float(fast.iloc[-1]),'atr_absolute':float(a.iloc[-1]),'mean_target':float(mean.iloc[-1]),'room':room,'required_room':cost_room,'atr_fraction':ap,'bar':int(frame.index[-1].timestamp()*1000),'vol':max(1e-8,float(close.pct_change(fill_method=None).iloc[-288:].std()))}

def target_weights(frames,balance,ticker,state,c,now):
 nav,values,units=nav_and_positions(balance,ticker,c['symbols']);shadow=copy.deepcopy(state);baseline,old_decisions,bar=original_targets(frames,balance,ticker,shadow,c,now);h=state.setdefault('hybrid_v3',{});v=state.setdefault('fusion_v4',{});positions=v.setdefault('positions',{});forced=h.setdefault('forced_exit',{});out={};decisions={};mean_candidates=[]
 h['guards']=shadow['hybrid_v3'].get('guards',{});h['atr_fractions']=shadow['hybrid_v3'].get('atr_fractions',{});h['reference_prices']=shadow['hybrid_v3'].get('reference_prices',{})
 for s,f in frames.items():
  sig=signal(f,ticker['Data'][s[:-4]+'/USD'],c);owned=units.get(s,0)>1e-8;meta=positions.get(s,{});kind=meta.get('kind','inherited' if owned else None);current=values.get(s,0)/nav;weight=0.;reason='NO_ENTRY'
  inherited_forced=shadow['hybrid_v3'].get('forced_exit',{}).get(s)
  if inherited_forced and (kind!='mean' or inherited_forced['reason']=='ATR_PROTECTIVE_EXIT'):forced.setdefault(s,inherited_forced)
  if kind=='mean' and owned:
   mark=float(ticker['Data'][s[:-4]+'/USD']['LastPrice']);elapsed=(bar-meta.get('entry_bar',bar))//300000
   if mark>=positive(meta.get('target_price'),'mean target'):forced.setdefault(s,{'reason':'MEAN_REVERSION_TARGET_EXIT','since_ms':now})
   elif elapsed>=c['fusion']['mean_max_hold_bars']:forced.setdefault(s,{'reason':'MEAN_REVERSION_TIME_EXIT','since_ms':now})
   elif not sig['sideways'] and not sig['trend_entry']:forced.setdefault(s,{'reason':'MEAN_REVERSION_REGIME_EXIT','since_ms':now})
   weight=current;reason='HOLD_MEAN_POSITION'
  elif owned:
   weight=current if not sig['trend_entry'] else baseline.get(s,current)
   reason='HOLD_NO_CHASE' if not sig['trend_entry'] else 'TREND_PULLBACK_TARGET';kind='trend' if kind is None else kind
  elif now<h.get('cooldown_until',{}).get(s,0):reason='REENTRY_COOLDOWN'
  elif sig['trend_entry']:weight=baseline.get(s,0);reason='TREND_PULLBACK_ENTRY';kind='trend'
  elif sig['mean_entry'] and s not in c['stock_symbols']:mean_candidates.append((s,sig));reason='MEAN_REVERSION_ENTRY';kind='mean'
  if s in forced:weight=0.;reason=forced[s]['reason']
  out[s]=weight;decisions[s]={**sig,'kind':kind,'reason':reason}
 if mean_candidates:
  total=sum(1/sig['vol'] for _,sig in mean_candidates)
  for s,sig in mean_candidates:
   if s not in forced:out[s]=min(c['fusion']['mean_asset_cap'],c['fusion']['mean_cap']/total/sig['vol'])
 for kind,limit in [('mean',c['fusion']['mean_cap']),('trend',c['fusion']['trend_cap'])]:
  group=[s for s in out if (decisions[s].get('kind')=='mean')==(kind=='mean')];total=sum(out[s] for s in group)
  if total>limit:
   for s in group:out[s]*=limit/total
 gross=sum(out.values())
 if gross:
  names=list(out);returns=pd.DataFrame({s:frames[s].close for s in names}).pct_change(fill_method=None).iloc[-576:].to_numpy();mix=np.array([out[s]/gross for s in names]);budget,_=risk_budget(returns,mix,c['daily_risk_target'],c['gross_cap'])
  if gross>budget:out={s:w*budget/gross for s,w in out.items()}
 out=cap_weights(out,c,nav)
 for s in out:decisions[s]['final_target']=out[s]
 h.update(targets=out,decisions=decisions,signal_bar=bar);protective_exits(state,ticker,units,c,now)
 for s in forced:out[s]=0.
 return out,decisions,bar

def finish_exits(state,units,exchange,ticker,c,now):
 original_finish(state,units,exchange,ticker,c,now);v=state.setdefault('fusion_v4',{});positions=v.setdefault('positions',{})
 for s in list(positions):
  if units.get(s,0)<=1e-8:positions.pop(s)
