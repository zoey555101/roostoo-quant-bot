import copy,contextlib,hashlib,io,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from quant.live import Blocked
from quant.hybrid_v3_strategy import DEFAULTS,config_load,nav_and_positions,cap_weights,protective_exits,target_weights,finish_exits
from quant.hybrid_v3_orders import passive_price,plan_orders,submit,reconcile,cancel,pending_guard
from quant.hybrid_v3_test import cycle,bind_state,reservations

class FakeExchange:
 def __init__(self):
  self.now=int(pd.Timestamp('2026-10-05T14:05:01Z').timestamp()*1000);self.offset=0;self.rows={};self.calls=[];self.next_id=1
  self.exchange={'IsRunning':True,'TradePairs':{s[:-4]+'/USD':{'CanTrade':True,'AmountPrecision':4,'PricePrecision':2,'MiniOrder':1,'AssetType':'stock' if s in DEFAULTS['stock_symbols'] else 'crypto'} for s in DEFAULTS['symbols']}}
  self.ticker={'Success':True,'ServerTime':self.now,'Data':{s[:-4]+'/USD':{'LastPrice':100.,'MaxBid':99.99,'MinAsk':100.01} for s in DEFAULTS['symbols']}}
  self.balance={'Success':True,'SpotWallet':{'USD':{'Free':50000.,'Lock':0.}},'MarginWallet':{}}
 def timestamp(self):return str(self.now)
 def sync_time(self):self.ticker['ServerTime']=self.now
 def request(self,path,params=None,signed=False,method='GET',allow_empty=False):
  params=params or {};self.calls.append((path,copy.deepcopy(params)))
  if path=='/v3/exchangeInfo':return copy.deepcopy(self.exchange)
  if path=='/v3/ticker':return copy.deepcopy(self.ticker)
  if path=='/v3/balance':return copy.deepcopy(self.balance)
  if path=='/v6/short_positions':return {'Success':True,'Positions':[]}
  if path=='/v3/query_order':
   rows=list(self.rows.values())
   if 'order_id' in params:rows=[r for r in rows if str(r['OrderID'])==str(params['order_id'])]
   if params.get('pending_only')=='TRUE':rows=[r for r in rows if r['Status']=='PENDING']
   return {'Success':True,'OrderMatched':copy.deepcopy(rows)}
  if path=='/v3/place_order':
   i=self.next_id;self.next_id+=1;q=float(params['quantity']);pair=params['pair'];coin=pair.split('/')[0];price=float(params.get('price') or self.ticker['Data'][pair]['LastPrice'])
   row={'OrderID':i,'Pair':pair,'Side':params['side'],'Type':params['type'],'Quantity':q,'Price':price,'FilledQuantity':0.,'FilledAverPrice':0.,'CommissionCoin':'USD','CommissionChargeValue':0.,'CommissionPercent':.0005 if params['type']=='LIMIT' else .001,'Role':'MAKER' if params['type']=='LIMIT' else 'TAKER','Status':'PENDING','CreateTimestamp':self.now,'FinishTimestamp':0}
   self.rows[i]=row;w=self.balance['SpotWallet'];w.setdefault(coin,{'Free':0.,'Lock':0.})
   if row['Side']=='BUY':w['USD']['Free']-=q*price;w['USD']['Lock']+=q*price
   else:w[coin]['Free']-=q;w[coin]['Lock']+=q
   if params['type']=='MARKET':self.fill(i,q,True)
   return {'Success':True,'OrderDetail':copy.deepcopy(row)}
  if path=='/v3/cancel_order':
   i=int(params['order_id']);r=self.rows[i];remain=r['Quantity']-r['FilledQuantity'];w=self.balance['SpotWallet'];coin=r['Pair'].split('/')[0]
   if r['Status']=='PENDING':
    if r['Side']=='BUY':w['USD']['Lock']-=remain*r['Price'];w['USD']['Free']+=remain*r['Price']
    else:w[coin]['Lock']-=remain;w[coin]['Free']+=remain
    r['Status']='CANCELED';r['FinishTimestamp']=self.now
   return {'Success':True,'CanceledList':[i]}
  raise AssertionError(path)
 def fill(self,i,quantity,terminal=False):
  r=self.rows[i];dq=quantity-r['FilledQuantity'];price=r['Price'];fee=dq*price*r['CommissionPercent'];w=self.balance['SpotWallet'];coin=r['Pair'].split('/')[0]
  if r['Side']=='BUY':w['USD']['Lock']-=dq*price;w[coin]['Free']+=dq;w['USD']['Free']-=fee
  else:w[coin]['Lock']-=dq;w['USD']['Free']+=dq*price-fee
  r.update(FilledQuantity=quantity,FilledAverPrice=price,CommissionChargeValue=r['CommissionChargeValue']+fee)
  if terminal:r.update(Status='FILLED',FinishTimestamp=self.now)

def state():return {'account_hash':'fake','hybrid_v3_mode':'TEST','intent':None,'confirmed_fills':0,'hybrid_v3':{}}
def order(side='BUY',kind='LIMIT',pair='BTC/USD'):
 o={'pair':pair,'side':side,'quantity':'0.4','type':kind,'estimated_notional':(39.996 if side=='BUY' else 40.004) if kind=='LIMIT' else 40.,'reason':'TARGET_REBALANCE','signal_bar':1}
 if kind=='LIMIT':o['price']='99.99' if side=='BUY' else '100.01'
 return o

def frames(client):
 ix=pd.date_range(end=pd.to_datetime(client.now,unit='ms',utc=True).floor('5min')-pd.Timedelta('5min'),periods=650,freq='5min')
 p=100*np.exp((np.arange(650)-649)*.0003+.0001*np.sin(np.arange(650)))
 out={s:pd.DataFrame({'open':p,'high':p*1.002,'low':p*.998,'close':p,'volume':100000},index=ix) for s in DEFAULTS['symbols']}
 return out

