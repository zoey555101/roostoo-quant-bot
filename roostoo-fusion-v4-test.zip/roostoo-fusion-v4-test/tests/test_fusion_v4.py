import copy,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from quant.live import Blocked
from quant.fusion_v4_strategy import DEFAULTS,digest,signal,target_weights
from quant.fusion_v4_test import bind
from quant.fusion_v4_engine import cycle
from quant.fusion_v4_orders import account_fills,plan_orders,submit,reconcile
from quant.fusion_v4_audit import analyze
from fusion_v4_fixtures import FakeExchange,frames,state,order

class FusionTests(unittest.TestCase):
 def bound(self):
  s=state();s.update(fusion_v4_mode='TEST',fusion_v4_config_hash=digest(DEFAULTS));s['fusion_v4']={'fill_cursor':0,'positions':{}};return s
 def test_dry_cycle_never_places_or_cancels(self):
  x=FakeExchange();s=self.bound()
  with tempfile.TemporaryDirectory() as d,patch('quant.fusion_v4_engine.market_frames',return_value=frames(x)):
   cycle(x,s,Path(d),DEFAULTS,False)
  self.assertFalse(any(path in ('/v3/place_order','/v3/cancel_order') for path,_ in x.calls))
 def test_portfolio_risk_does_not_wait_for_signal_download(self):
  x=FakeExchange();s=self.bound();s['high_water']=52000.;x.balance['SpotWallet']['BTC']={'Free':1.,'Lock':0.}
  with tempfile.TemporaryDirectory() as d,patch('quant.fusion_v4_engine.market_frames',side_effect=AssertionError('risk must bypass data')):
   output=cycle(x,s,Path(d),DEFAULTS,False)
  self.assertTrue(s['halted']);self.assertEqual(output['orders'][0]['reason'],'PORTFOLIO_RISK_EXIT')
 def test_actual_account_cannot_bind(self):
  s=state();s['mode']='COMPETITION'
  with self.assertRaises(Blocked):bind(s,'fake',DEFAULTS)
 def test_binding_preserves_halt_highwater_and_unknown_order(self):
  s=state();s.update(halted=True,high_water=51000);s['hybrid_v3_config_hash']='old';bind(s,'fake',DEFAULTS)
  self.assertTrue(s['halted']);self.assertEqual(s['high_water'],51000);self.assertEqual(s['hybrid_v3_config_hash'],'old')
  s['intent']={'order_id':None}
  with self.assertRaises(Blocked):bind(s,'fake',DEFAULTS)
 def test_entry_not_at_overheated_high(self):
  x=FakeExchange();f=frames(x)['BTCUSDT'];f.loc[f.index[-1],'close']=110.;f.loc[f.index[-1],'high']=111.
  q={'LastPrice':110.,'MaxBid':109.99,'MinAsk':110.01}
  self.assertFalse(signal(f,q,DEFAULTS)['trend_entry'])
 def test_falling_price_not_mean_entry(self):
  x=FakeExchange();f=frames(x)['BTCUSDT'];f.loc[f.index[-3:],'close']=[100.,99.,98.];f.loc[f.index[-3:],'low']=[99.,98.,97.]
  self.assertFalse(signal(f,{'LastPrice':98.,'MaxBid':97.99,'MinAsk':98.01},DEFAULTS)['mean_entry'])
 def test_mean_entry_requires_bounce_room_and_flat_regime(self):
  x=FakeExchange();f=frames(x)['BTCUSDT'];p=100+.5*np.sin(np.arange(len(f))*.13);p[-3:]=[98.,98.1,98.2]
  f['close']=p;f['open']=p;f['high']=p+.8;f['low']=p-.8
  sig=signal(f,{'LastPrice':98.2,'MaxBid':98.19,'MinAsk':98.21},DEFAULTS)
  self.assertTrue(sig['mean_entry']);self.assertFalse(sig['trend_entry']);self.assertGreater(sig['room'],sig['required_room'])
 def test_no_new_order_averaging_down_mean_position(self):
  x=FakeExchange();s=self.bound();x.balance['SpotWallet']['BTC']={'Free':.1,'Lock':0.}
  s['fusion_v4']['positions']['BTCUSDT']={'kind':'mean','quantity':.1,'basis_known':True,'cost_usd':10.}
  s['hybrid_v3']['decisions']={'BTCUSDT':{'kind':'mean','mean_target':105.}}
  _,orders=plan_orders(x.exchange,x.ticker,x.balance,{'BTCUSDT':.005},s,DEFAULTS,x.now);self.assertEqual(orders,[])
 def test_weighted_cost_not_last_slice(self):
  s=self.bound();s['fusion_v4']['positions']['BTCUSDT']={'kind':'trend','basis_known':True,'quantity':0.,'cost_usd':0.}
  s['hybrid_v3']['fills']=[{'pair':'BTC/USD','side':'BUY','quantity_delta':1.,'notional_delta':100.,'fee_usd':.1},{'pair':'BTC/USD','side':'BUY','quantity_delta':1.,'notional_delta':120.,'fee_usd':.12}]
  account_fills(s);m=s['fusion_v4']['positions']['BTCUSDT'];self.assertAlmostEqual(m['cost_usd']/m['quantity'],110.11)
  account_fills(s);self.assertEqual(m['quantity'],2.)
 def test_loss_gate_only_ordinary_sell_and_risk_bypass(self):
  x=FakeExchange();x.balance['SpotWallet']['BTC']={'Free':1.,'Lock':0.};s=self.bound();s['fusion_v4']['positions']['BTCUSDT']={'kind':'trend','basis_known':True,'quantity':1.,'cost_usd':101.}
  _,orders=plan_orders(x.exchange,x.ticker,x.balance,{'BTCUSDT':0.},s,DEFAULTS,x.now);self.assertEqual(orders,[])
  s['hybrid_v3']['forced_exit']={'BTCUSDT':{'reason':'ATR_PROTECTIVE_EXIT','since_ms':x.now}}
  _,orders=plan_orders(x.exchange,x.ticker,x.balance,{'BTCUSDT':0.},s,DEFAULTS,x.now);self.assertEqual(orders[0]['type'],'MARKET')
 def test_mean_cost_room_rechecked_at_execution(self):
  x=FakeExchange();s=self.bound();s['hybrid_v3']['decisions']={'BTCUSDT':{'kind':'mean','mean_target':100.2}}
  _,orders=plan_orders(x.exchange,x.ticker,x.balance,{'BTCUSDT':.005},s,DEFAULTS,x.now);self.assertEqual(orders,[])
 def test_immediate_fill_cost_book_and_recovery_idempotent(self):
  x=FakeExchange();s=self.bound();s['hybrid_v3']['decisions']={'BTCUSDT':{'kind':'mean','mean_target':105.}}
  with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'ROOSTOO_ACCOUNT_MODE':'TEST'}):
   submit(x,s,Path(d),order(kind='MARKET'),DEFAULTS,True);reconcile(x,s,Path(d));m=s['fusion_v4']['positions']['BTCUSDT'];self.assertAlmostEqual(m['quantity'],.4);self.assertAlmostEqual(m['cost_usd'],40.04);self.assertEqual(m['target_price'],105.)
   self.assertAlmostEqual(s['fusion_v4']['fees_usd'],.04)
 def test_mean_target_exit_is_not_delayed_by_profit_gate(self):
  x=FakeExchange();s=self.bound();x.balance['SpotWallet']['BTC']={'Free':1.,'Lock':0.};s['fusion_v4']['positions']['BTCUSDT']={'kind':'mean','quantity':1.,'basis_known':True,'cost_usd':101.,'entry_bar':x.now,'target_price':99.}
  target_weights({'BTCUSDT':frames(x)['BTCUSDT']},x.balance,x.ticker,s,DEFAULTS,x.now)
  self.assertEqual(s['hybrid_v3']['forced_exit']['BTCUSDT']['reason'],'MEAN_REVERSION_TARGET_EXIT')
 def test_fifo_reports_fees_and_unknown_inherited_sales(self):
  f=lambda side,q,n,fee,ms:{'pair':'BTC/USD','side':side,'quantity_delta':q,'notional_delta':n,'fee_usd':fee,'observed_ms':ms,'order_id':str(ms),'reason':'test'}
  r=analyze({'hybrid_v3':{'fills':[f('SELL',1,90,.09,1),f('BUY',1,100,.1,2),f('SELL',1,99,.099,3)]}})
  self.assertAlmostEqual(r['matched_net_pnl'],-1.199);self.assertEqual(r['by_pair']['BTC/USD']['unmatched_sold_quantity'],1);self.assertAlmostEqual(r['fees_usd'],.289)
if __name__=='__main__':unittest.main()
