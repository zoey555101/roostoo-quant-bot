# Fusion V4 TEST candidate

This is a fixed, unoptimized hypothesis, not a profitability result. No historical backtest or actual-account operation was performed. Original Hybrid V3 files and the actual service are untouched. No actual runner or activation script exists in this package.

## What changed

- Trend sleeve: retains the existing 24h momentum and EMA60/150 trend, but requires two rising closed bars and price within -0.5 to +1 ATR of EMA60. This reduces chasing; it does not identify a guaranteed bottom.
- Mean-reversion sleeve: crypto only, restricted to a flat EMA trend/slope and limited 24h movement. A 4h price deviation below -1.5 standard deviations must turn upward for two bars, still below -0.5 standard deviations. Distance to the mean must exceed conservative round-trip taker fees, quoted spread and 0.2% margin. Distance is not an expected return estimate.
- Mean positions keep their entry-time mean target, expire after 24 closed five-minute bars (two hours), and exit if the sideways regime breaks. No additional BUY order into a held mean position. Partially filled original orders still reconcile normally.
- Normal target reductions with a known USD weighted acquisition cost must cover acquisition fee, estimated exit fee and 0.1% margin. All confirmed trend, ATR, regime, time, portfolio and exposure-cap exits bypass this rule. Losing risk exits remain essential.
- Portfolio sizing continues to use historical covariance/volatility; sleeves have ceilings of 50% trend / 10% mean, 3% per mean asset, 60% overall and 30% stock tokens. These are ceilings, not exposure targets or guaranteed risk bounds. TEST additionally caps each asset at $300, total exposure at $3000, each order at $50, four normal orders / $200 per signal bar.
- Passive LIMIT for normal execution; confirmed exits retain the existing timeout-to-MARKET policy. Fees remain 0.05% maker / 0.1% taker. Five-minute bars produce opportunities, not mandatory trades.
- 3% portfolio high-water halt, existing position stops and pending-order recovery remain. No high-water, halt, unknown order or account history is reset. One TEST account process at a time.

## Actual loss audit first

The audit reads a local state file only. No credentials or account request is used. It reports available V3 fees/turnover, available-record FIFO gross/net P&L and unmatched inherited sales. It cannot establish whole-account loss from missing earlier trades or unknown inherited costs. It does not measure slippage without submission quotes. A high-buy/low-sell stop can be appropriate; many repeated losing reversals are the concern.

## Installation and running

See COMMANDS.txt. Stop the old TEST runner before binding the candidate. Use the original bound TEST directory. Binding backs up TEST state and archives the old Hybrid verification proof; the old proof is not valid for this candidate. Existing inherited holdings retain unknown cost basis and existing protective exits. Default execution is dry-run; --execute-test can trade only a TEST profile.

An installed package is not an AWS deployment or a profitability validation. Send the actual audit output before considering any actual-account migration. Do not erase state or override a halted account to test new entries.
