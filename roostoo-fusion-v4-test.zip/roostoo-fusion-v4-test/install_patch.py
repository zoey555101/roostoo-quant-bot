"""Additive installer. Never edits original modules, credentials, runtime or service."""
import argparse,hashlib,json,py_compile,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('project');p.add_argument('--audit-only',action='store_true');a=p.parse_args();source=Path(__file__).resolve().parent;target=Path(a.project).expanduser().resolve();m=json.loads((source/'manifest.json').read_text())
if not (target/'quant').is_dir():raise SystemExit('Use the project directory containing quant; not your home directory')
files=['quant/fusion_v4_audit.py'] if a.audit_only else list(m['files'])
errors=[]
for f in files:
 data=(source/f).read_bytes()
 if hashlib.sha256(data).hexdigest()!=m['files'][f]:errors.append('Package hash mismatch: '+f)
 dest=target/f
 if dest.is_symlink():errors.append('Refusing target symlink: '+f)
 elif dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()!=m['files'][f]:errors.append('Different candidate already exists; refusing overwrite: '+f)
 if f.endswith('.py'):compile(data,f,'exec')
if not a.audit_only:
 for f,h in m['dependencies'].items():
  if not (target/f).is_file() or hashlib.sha256((target/f).read_bytes()).hexdigest()!=h:errors.append('Existing dependency differs: '+f+'; install --audit-only and send this message')
if errors:raise SystemExit('\n'.join(errors))
for f in files:
 dest=target/f;dest.parent.mkdir(parents=True,exist_ok=True)
 if not dest.exists():shutil.copy2(source/f,dest)
print('Installed '+str(len(files))+' additive files. No original code, runtime, credentials or service changed.')
