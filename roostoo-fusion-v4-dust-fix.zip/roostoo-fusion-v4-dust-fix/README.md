# Fusion TEST negative-ADA repair and sell safeguard

Observed: ADA market SELL 147.9 filled, commission in USD, then the server returned ADA Free=-0.1 with zero Lock/PendingOrders/ShortCollateral. Root cause is not confirmed; no pre-submit unrounded inventory or complete settlement trace is available. The fix bounds a one-quantity-unit wallet reporting discrepancy, not arbitrary deficits.

Future Fusion TEST SELL plans cannot consume the last amount-precision unit of reported Free. Intermediate slices stay unchanged. Minimum-order residues remain real holdings/NAV; negative Free is still fatal and never normalized. Actual Hybrid V3 order code is untouched; no actual restart needed.

A separate repair command, read-only by default, allows a ONE-TIME dedicated TEST market ADA BUY of <=$20 notional plus 0.1% commission, only if the server confirms ADA Free between -0.1 and 0, deficit value <=$1, all other fields valid and reservations/shorts absent. It validates original TEST account binding, fixed config, locks and halt; reconciles orders before planning. Unknown order or unresolved cancellation prevents repair. The durable repair-attempt marker prevents repeated purchases after uncertain outcomes. Existing exits and high water are retained.

The repair is a balance operation, not a new mean-reversion or trend entry, and does not validate strategy profitability. After recovery, existing ADA exit may sell this small position safely and leave an unsellable one-unit residue. Repair postcheck stores actual available units with UNKNOWN cost basis, not an invented investment cost. Never delete state or clear forced exits.

269 unit tests passed, including eight new checks for final-sell margin, unaffected intermediate slices, negative-wallet rejection, residue rejection, bounded one-time repair, larger/other deficit refusal reservation refusal and safety-unit residual completion. Tests use fake data. No real API request or trade was made during development.
