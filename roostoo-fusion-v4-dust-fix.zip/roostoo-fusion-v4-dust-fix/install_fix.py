"""TEST source repair only. No credential/runtime/service mutation."""
import argparse,fcntl,hashlib,json,os,shutil,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('project');a=p.parse_args();root=Path(a.project).resolve();source=Path(__file__).resolve().parent;m=json.loads((source/'manifest.json').read_text());s=json.loads((root/'runtime/test/state.json').read_text())
if s.get('mode')=='COMPETITION' or s.get('fusion_v4_mode')!='TEST' or not s.get('account_hash'):raise SystemExit('Bound Fusion TEST state required')
lock_path=Path.home()/'.roostoo-locks'/(s['account_hash']+'.lock');backup=root/'code_backups/fusion_v4_dust_v1'
with open(lock_path,'a') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise SystemExit('Stop TEST runner before installing; actual service stays running')
 jobs=[];errors=[]
 for name,info in m.items():
  src=source/name;dest=root/name
  if hashlib.sha256(src.read_bytes()).hexdigest()!=info['new']:errors.append('Package differs: '+name)
  compile(src.read_bytes(),name,'exec')
  if dest.is_symlink():errors.append('Refusing symlink: '+name);continue
  current=hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None
  if current==info['new']:continue
  if current!=info['old']:errors.append('Existing source differs: '+name);continue
  b=backup/name
  if dest.exists() and b.exists() and hashlib.sha256(b.read_bytes()).hexdigest()!=info['old']:errors.append('Backup differs: '+name)
  jobs.append((name,src,dest))
 if errors:raise SystemExit('\n'.join(errors))
 for name,src,dest in jobs:
  if dest.exists():
   b=backup/name;b.parent.mkdir(parents=True,exist_ok=True)
   if not b.exists():shutil.copy2(dest,b)
  dest.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(dir=dest.parent,prefix='.dust-')
  with os.fdopen(fd,'wb') as out:out.write(src.read_bytes())
  os.chmod(tmp,0o600);os.replace(tmp,dest)
 print('Installed '+str(len(jobs))+' TEST-only source files. Original source backup: '+str(backup))
 print('No balance clamping, runtime/config/credentials/service changes or order submission.')
