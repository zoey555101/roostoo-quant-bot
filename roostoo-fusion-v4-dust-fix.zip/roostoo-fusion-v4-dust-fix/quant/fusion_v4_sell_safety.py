"""Conservative sell cap for a wallet potentially rounded by one amount unit."""
from decimal import Decimal,ROUND_DOWN
from .live import Blocked,positive

def safe_sell(order,balance,exchange,ticker):
 if order['side']!='SELL':return order
 pair=order['pair'];coin=pair.split('/')[0];rule=exchange['TradePairs'][pair];precision=int(rule['AmountPrecision'])
 if not 0<=precision<=12:raise Blocked('Unsupported amount precision')
 wallet=balance.get('SpotWallet',balance.get('Wallet',{}));free=Decimal(str(wallet[coin]['Free']))
 if not free.is_finite() or free<0:raise Blocked('Invalid Free; never clamp negative wallet balance')
 quantum=Decimal(1).scaleb(-precision)
 # Retain one quantity unit when the order would exhaust reported available units.
 # This bounds the observed one-unit reporting discrepancy, not arbitrary deficits.
 maximum=max(Decimal(0),free.quantize(quantum,rounding=ROUND_DOWN)-quantum)
 quantity=min(Decimal(order['quantity']),maximum)
 if quantity<=0:return None
 price=Decimal(str(order.get('price',ticker['Data'][pair]['MaxBid'])))
 notional=quantity*price
 if notional<=Decimal(str(rule['MiniOrder'])):return None
 return {**order,'quantity':format(quantity,'f'),'estimated_notional':float(notional)}

def finish_margin_residue(state,units,exchange,ticker,c,now):
 h=state.setdefault('hybrid_v3',{});forced=h.setdefault('forced_exit',{})
 for symbol in list(forced):
  pair=symbol[:-4]+'/USD';rule=exchange['TradePairs'][pair];q=Decimal(str(units.get(symbol,0)));precision=int(rule['AmountPrecision'])
  if not 0<=precision<=12:raise Blocked('Unsupported amount precision')
  quantum=Decimal(1).scaleb(-precision)
  if 0<q<=quantum:
   h.setdefault('dust',{})[symbol]=float(q)*float(ticker['Data'][pair]['MaxBid'])
   h.setdefault('cooldown_until',{})[symbol]=now+c['cooldown_bars']*300000
   forced.pop(symbol);h.setdefault('guards',{}).pop(symbol,None)
