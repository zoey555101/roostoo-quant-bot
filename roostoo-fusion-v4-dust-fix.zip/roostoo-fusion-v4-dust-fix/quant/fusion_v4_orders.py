"""TEST-only execution wrapper and weighted acquisition-cost gate."""
import os
from . import hybrid_v3_orders as base
from .live import Blocked
from .fusion_v4_strategy import digest
from .fusion_v4_sell_safety import safe_sell
save=base.save
pending_guard=base.pending_guard

def assert_candidate(state,c,execute):
 base.assert_test(state,execute)
 if state.get('fusion_v4_mode')!='TEST' or state.get('fusion_v4_config_hash')!=digest(c):
  raise Blocked('Dedicated fixed Fusion TEST binding required')

def account_fills(state):
 v=state.setdefault('fusion_v4',{});fills=state.get('hybrid_v3',{}).get('fills',[]);cursor=v.get('fill_cursor')
 if cursor is None or cursor>len(fills):raise Blocked('Fusion fill cursor missing or inconsistent')
 positions=v.setdefault('positions',{})
 for f in fills[cursor:]:
  v['fees_usd']=v.get('fees_usd',0)+float(f.get('fee_usd',0));v['filled_notional']=v.get('filled_notional',0)+float(f['notional_delta'])
  symbol=f['pair'].split('/')[0]+'USDT';q=float(f['quantity_delta']);n=float(f['notional_delta']);fee=float(f.get('fee_usd',0));meta=positions.setdefault(symbol,{'kind':'inherited','quantity':0.,'basis_known':False})
  if f['side']=='BUY':
   prior=float(meta.get('quantity',0));meta['quantity']=prior+q
   if meta.get('basis_known'):meta['cost_usd']=meta.get('cost_usd',0)+n+fee
   if f.get('commission_coin','USD')!='USD' and f.get('fee_native',0):meta['basis_known']=False
  elif f['side']=='SELL':
   prior=float(meta.get('quantity',0));sold=min(q,prior)
   if meta.get('basis_known') and prior:meta['cost_usd']=meta.get('cost_usd',0)*(1-sold/prior)
   meta['quantity']=max(0,prior-q)
   if meta['quantity']<=1e-8:positions.pop(symbol,None)
 v['fill_cursor']=len(fills)

def reconcile(client,state,directory):
 row=base.reconcile(client,state,directory);account_fills(state);save(directory,state);return row

def cancel(client,state,directory,execute,reason):
 if state.get('fusion_v4_mode')!='TEST':raise Blocked('Fusion TEST binding required')
 try:return base.cancel(client,state,directory,execute,reason)
 finally:account_fills(state);save(directory,state)

def submit(client,state,directory,order,c,execute):
 assert_candidate(state,c,execute)
 symbol=order['pair'].split('/')[0]+'USDT';v=state['fusion_v4'];positions=v.setdefault('positions',{})
 if order['side']=='BUY' and symbol not in positions:
  decision=state['hybrid_v3']['decisions'][symbol]
  positions[symbol]={'kind':decision['kind'],'quantity':0.,'cost_usd':0.,'basis_known':True,'entry_bar':order['signal_bar'],'target_price':decision['mean_target']}
  save(directory,state)
 try:return base.submit(client,state,directory,order,c,execute)
 finally:account_fills(state);save(directory,state)

def plan_orders(exchange,ticker,balance,weights,state,c,now):
 nav,orders=base.plan_orders(exchange,ticker,balance,weights,state,c,now);accepted=[]
 for order in orders:
  order=safe_sell(order,balance,exchange,ticker)
  if order is None:continue
  symbol=order['pair'].split('/')[0]+'USDT';decision=state.get('hybrid_v3',{}).get('decisions',{}).get(symbol,{});meta=state.get('fusion_v4',{}).get('positions',{}).get(symbol,{})
  if order['side']=='BUY':
   if meta.get('kind')=='mean' and meta.get('quantity',0)>1e-8:continue
   ask=float(ticker['Data'][order['pair']]['MinAsk'])
   if decision.get('kind')=='mean':
    quote=ticker['Data'][order['pair']];spread=(float(quote['MinAsk'])-float(quote['MaxBid']))/float(quote['LastPrice']);required=2*c['taker_fee']+2*spread+c['fusion']['net_room_margin']
    if decision.get('mean_target',0)/ask-1<=required:continue
   elif decision.get('kind') in ('trend','inherited'):
    location=(ask-decision.get('ema_fast',ask))/max(decision.get('atr_absolute',0),1e-10)
    if not decision.get('trend_entry') or not c['fusion']['entry_atr_min']<=location<=c['fusion']['entry_atr_max']:continue
   else:continue
  if order['side']=='SELL' and order['reason']=='TARGET_REBALANCE' and meta.get('basis_known') and meta.get('quantity',0)>0:
   unit_cost=meta['cost_usd']/meta['quantity'];price=float(order.get('price',ticker['Data'][order['pair']]['MaxBid']))
   if price*(1-c['taker_fee'])<unit_cost*(1+c['fusion']['ordinary_profit_margin']):continue
  accepted.append(order)
 return nav,accepted
