"""One explicit TEST-only ADA repair; no real-account path or balance clamping."""
import argparse,fcntl,hashlib,json,math,os
from pathlib import Path
from .live import Blocked,positive,quantize,spot_wallet,short_check,audit
from .cross_asset_v2_test import load_profile
from .cross_asset_v2_engine import quote
from .fusion_v4_strategy import config_load,digest
from .fusion_v4_orders import assert_candidate,reconcile,pending_guard,account_fills,save
from .hybrid_v3_orders import submit
from .roostoo import Roostoo
REASON='ADA_NEGATIVE_BALANCE_REPAIR_V4'

def plan_repair(balance,exchange,ticker,state,c):
 if balance.get('Success') is not True or balance.get('MarginWallet',{}):raise Blocked('Confirmed spot-only TEST balance required')
 wallet=balance.get('SpotWallet',balance.get('Wallet'))
 if not isinstance(wallet,dict) or not isinstance(wallet.get('USD'),dict) or not isinstance(wallet.get('ADA'),dict):raise Blocked('USD/ADA wallet required')
 deficit=0.
 for coin,entry in wallet.items():
  for field in ('Free','Lock','PendingOrders','ShortCollateral'):
   value=float(entry.get(field,0))
   if not math.isfinite(value):raise Blocked('Nonfinite wallet value')
   if field!='Free' and value!=0:raise Blocked('All reservations/short collateral must be zero')
   if value<0:
    if coin!='ADA' or field!='Free' or value<-.1-1e-12:raise Blocked('Only observed <=0.1 ADA Free deficit supported')
    deficit=-value
 if not deficit:return None
 if state.get('fusion_v4',{}).get('dust_repairs',{}).get('ADA') or any(o.get('reason')==REASON for o in state.get('hybrid_v3',{}).get('completed_orders',[])):raise Blocked('Repair already attempted; inspect instead of repeat')
 rule=exchange['TradePairs']['ADA/USD'];q=ticker['Data']['ADA/USD'];ask=positive(q['MinAsk'],'ask');bid=positive(q['MaxBid'],'bid');mark=positive(q['LastPrice'],'mark')
 if exchange.get('IsRunning') is not True or rule.get('CanTrade') is not True or ask<bid or (ask-bid)/ask>.005 or deficit*mark>1:raise Blocked('Repair quote or deficit outside bounds')
 quantity=quantize(20/ask,rule['AmountPrecision']);notional=float(quantity)*ask
 if quantity<=deficit*2 or notional<=positive(rule['MiniOrder'],'minimum',True) or notional>20.000001:raise Blocked('Repair amount outside bounds')
 if positive(wallet['USD'].get('Free',0),'free USD')<notional*(1+c['taker_fee']):raise Blocked('Insufficient TEST cash')
 return dict(pair='ADA/USD',side='BUY',quantity=format(quantity,'f'),type='MARKET',estimated_notional=notional,reason=REASON,signal_bar=None)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute-test',action='store_true');a=p.parse_args();d=Path('runtime/test');c=config_load('fusion.v4.test.json');profile=load_profile(d/'credentials.json');account=hashlib.sha256(profile['api_key'].encode()).hexdigest();locks=Path.home()/'.roostoo-locks';os.umask(0o077)
 if json.loads((locks/(account+'.json')).read_text()).get('state_dir')!=str(d.resolve()):raise Blocked('Original TEST state binding required')
 with open(locks/(account+'.lock'),'a') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise Blocked('Stop TEST runner; actual service remains independent')
  s=json.loads((d/'state.json').read_text())
  if s.get('account_hash')!=account or s.get('mode')=='COMPETITION' or s.get('fusion_v4_mode')!='TEST' or s.get('fusion_v4_config_hash')!=digest(c):raise Blocked('Dedicated registered Fusion TEST binding required')
  if s.get('halted') or (d/'STOP').exists():raise Blocked('Retain risk halt; no repair BUY')
  for key,env in [('api_key','ROOSTOO_API_KEY'),('secret','ROOSTOO_SECRET_KEY')]:os.environ[env]=profile[key]
  os.environ['ROOSTOO_ACCOUNT_MODE']='TEST';client=Roostoo();client.sync_time()
  if abs(client.offset)>60000:raise Blocked('Clock mismatch')
  reconcile(client,s,d);pending_guard(client,s);short_check(client)
  if s.get('intent'):raise Blocked('Unresolved owned order retained; repair blocked')
  balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True);ticker=quote(client);ex=client.request('/v3/exchangeInfo');order=plan_repair(balance,ex,ticker,s,c)
  if order is None:spot_wallet(balance);print('ADA balance already nonnegative; no order submitted');return
  print(json.dumps({'mode':'FUSION_ADA_REPAIR_TEST','execute':a.execute_test,'maximum_notional_usd':20,'order':order,'root_cause_confirmed':False}))
  if not a.execute_test:return
  assert_candidate(s,c,True);s['fusion_v4'].setdefault('dust_repairs',{})['ADA']={'attempted_ms':int(client.timestamp()),'maximum_notional_usd':20};save(d,s)
  audit(d,'ada_negative_balance_repair',before=balance.get('SpotWallet',balance.get('Wallet'))['ADA'],maximum_notional_usd=20)
  try:submit(client,s,d,order,c,True)
  finally:account_fills(s);save(d,s)
  if s.get('intent'):raise Blocked('Repair outcome unresolved; no repeat or reset allowed')
  post=spot_wallet(client.request('/v3/balance',{'timestamp':client.timestamp()},True));entry=post['ADA'];s['fusion_v4'].setdefault('positions',{})['ADAUSDT']={'kind':'inherited','quantity':float(entry['Free'])+float(entry.get('Lock',0)),'basis_known':False};save(d,s)
  print(json.dumps({'repair':'ADA_BALANCE_NONNEGATIVE','ADA':entry,'next':'Resume Fusion TEST runner; safe final SELL retains one amount unit'}))
if __name__=='__main__':
 try:main()
 except Blocked as e:raise SystemExit('Stopped safely: '+str(e))
