import copy,unittest
from quant.live import Blocked
from quant.fusion_v4_sell_safety import safe_sell,finish_margin_residue
from quant.fusion_v4_dust_repair import plan_repair
from quant.fusion_v4_strategy import DEFAULTS

class DustTests(unittest.TestCase):
 def setUp(self):
  self.balance={'Success':True,'SpotWallet':{'USD':{'Free':49000,'Lock':0,'PendingOrders':0},'ADA':{'Free':147.9,'Lock':0,'PendingOrders':0}},'MarginWallet':{}}
  self.exchange={'IsRunning':True,'TradePairs':{'ADA/USD':{'CanTrade':True,'AmountPrecision':1,'MiniOrder':1}}}
  self.ticker={'Data':{'ADA/USD':{'LastPrice':.2564,'MaxBid':.2564,'MinAsk':.2565}}}
  self.order={'pair':'ADA/USD','side':'SELL','quantity':'147.9','type':'MARKET','estimated_notional':37.92}
 def test_final_sell_reserves_one_unit(self):
  order=safe_sell(self.order,self.balance,self.exchange,self.ticker)
  self.assertEqual(order['quantity'],'147.8');self.assertAlmostEqual(order['estimated_notional'],147.8*.2564)
 def test_partial_slice_unchanged(self):
  self.balance['SpotWallet']['ADA']['Free']=1000.;self.order['quantity']='195.0'
  self.assertEqual(safe_sell(self.order,self.balance,self.exchange,self.ticker)['quantity'],'195.0')
 def test_margin_residue_finishes_even_with_zero_minimum(self):
  self.exchange['TradePairs']['ADA/USD']['MiniOrder']=0
  s={'hybrid_v3':{'forced_exit':{'ADAUSDT':{'reason':'ATR_PROTECTIVE_EXIT'}},'guards':{'ADAUSDT':{}}}}
  finish_margin_residue(s,{'ADAUSDT':.1},self.exchange,self.ticker,DEFAULTS,100)
  self.assertEqual(s['hybrid_v3']['forced_exit'],{});self.assertGreater(s['hybrid_v3']['dust']['ADAUSDT'],0);self.assertGreater(s['hybrid_v3']['cooldown_until']['ADAUSDT'],100)
 def test_negative_free_is_never_normalized(self):
  self.balance['SpotWallet']['ADA']['Free']=-.1
  with self.assertRaises(Blocked):safe_sell(self.order,self.balance,self.exchange,self.ticker)
 def test_unsellable_residue_no_order(self):
  self.balance['SpotWallet']['ADA']['Free']=.1;self.order['quantity']='0.1'
  self.assertIsNone(safe_sell(self.order,self.balance,self.exchange,self.ticker))
 def test_repair_bounded_and_repeat_refused(self):
  self.balance['SpotWallet']['ADA']['Free']=-.1;s={'fusion_v4':{}}
  o=plan_repair(self.balance,self.exchange,self.ticker,s,DEFAULTS)
  self.assertEqual(o['side'],'BUY');self.assertLessEqual(o['estimated_notional'],20)
  s['fusion_v4']['dust_repairs']={'ADA':{'attempted_ms':1}}
  with self.assertRaises(Blocked):plan_repair(self.balance,self.exchange,self.ticker,s,DEFAULTS)
 def test_other_negative_or_larger_deficit_blocked(self):
  self.balance['SpotWallet']['ADA']['Free']=-.2
  with self.assertRaises(Blocked):plan_repair(self.balance,self.exchange,self.ticker,{},DEFAULTS)
  self.balance['SpotWallet']['ADA']['Free']=-.1;self.balance['SpotWallet']['ETH']={'Free':-.0001}
  with self.assertRaises(Blocked):plan_repair(self.balance,self.exchange,self.ticker,{},DEFAULTS)
 def test_reservations_block_repair(self):
  self.balance['SpotWallet']['ADA'].update(Free=-.1,Lock=.1)
  with self.assertRaises(Blocked):plan_repair(self.balance,self.exchange,self.ticker,{},DEFAULTS)
if __name__=='__main__':unittest.main()
