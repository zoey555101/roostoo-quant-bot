import copy,hashlib,json,os,tempfile,unittest,contextlib,io
from pathlib import Path
from unittest.mock import patch
import pandas as pd
from test_hybrid_v3 import FakeExchange,state,order,frames
from quant.live import Blocked
from quant.hybrid_v3_strategy import DEFAULTS as TEST
from quant.hybrid_v3_orders import submit,reconcile,cancel
from quant.hybrid_v3_probe import verify_rows
from quant.hybrid_v3_live_strategy import DEFAULTS as LIVE
from quant.hybrid_v3_live_orders import submit as live_submit,plan_orders
from quant.hybrid_v3_live_engine import cycle
from quant.migrate_hybrid_v3 import digest,preflight,apply_state

class ActivationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name);self.client=FakeExchange()
 def tearDown(self):self.tmp.cleanup()
 def actual(self):
  return dict(account_hash='fake',mode='COMPETITION',armed_verification=True,hybrid_v3_mode='COMPETITION',config_hash=digest(LIVE),hybrid_v3_config_hash=digest(LIVE),hybrid_v3_verified={'verification':'PASSED_EXECUTION'},intent=None,confirmed_fills=13,high_water=50020,hybrid_v3={})
 def evidence(self):
  s=state()
  with patch.dict(os.environ,{'ROOSTOO_ACCOUNT_MODE':'TEST'}):
   submit(self.client,s,self.d,order(),TEST,True);self.client.fill(1,.4,True);reconcile(self.client,s,self.d)
   submit(self.client,s,self.d,order(kind='MARKET'),TEST,True)
   submit(self.client,s,self.d,order(),TEST,True);cancel(self.client,s,self.d,True,'EXPLICIT_CANCEL_PROBE')
  return s
 def test_independent_maker_taker_cancel_confirmation(self):
  s=self.evidence();result=verify_rows(self.client,s)
  self.assertEqual([r['check'] for r in result],['maker','taker','cancel'])
  self.assertEqual([r['commission_percent'] for r in result[:2]],[.0005,.001])
 def test_server_cancel_still_pending_rejected(self):
  s=self.evidence();self.client.rows[3]['Status']='PENDING'
  with self.assertRaises(Blocked):verify_rows(self.client,s)
 def test_wrong_server_maker_fee_rejected(self):
  s=self.evidence();self.client.rows[1]['CommissionPercent']=.001
  with self.assertRaises(Blocked):verify_rows(self.client,s)
 def test_local_only_cancel_evidence_rejected(self):
  s=self.evidence();del self.client.rows[3]
  with self.assertRaises(Blocked):verify_rows(self.client,s)
 def test_actual_rejects_test_environment(self):
  with patch.dict(os.environ,{'ROOSTOO_ACCOUNT_MODE':'TEST'}),self.assertRaises(Blocked):live_submit(self.client,self.actual(),self.d,order(),LIVE,True)
  self.assertFalse(self.client.rows)
 def test_actual_rejects_missing_proof(self):
  s=self.actual();s.pop('hybrid_v3_verified')
  with patch.dict(os.environ,{'ROOSTOO_ACCOUNT_MODE':'COMPETITION'}),self.assertRaises(Blocked):live_submit(self.client,s,self.d,order(),LIVE,True)
 def test_actual_submit_and_recovery_use_live_config(self):
  s=self.actual()
  with patch.dict(os.environ,{'ROOSTOO_ACCOUNT_MODE':'COMPETITION'}):live_submit(self.client,s,self.d,order(),LIVE,True)
  self.assertEqual(s['intent']['order_id'],1);self.assertEqual(s['confirmed_fills'],13)
 def test_actual_slice_respects_5000_cap(self):
  s=self.actual();s['hybrid_v3']['signal_bar']=1
  _,orders=plan_orders(self.client.exchange,self.client.ticker,self.client.balance,{'BTCUSDT':.1},s,LIVE,self.client.now)
  self.assertTrue(orders);self.assertGreater(orders[0]['estimated_notional'],50)
  self.assertLessEqual(orders[0]['estimated_notional'],5000)
 def test_actual_dry_run_no_order_writes(self):
  s=self.actual()
  with patch('quant.hybrid_v3_live_engine.market_frames',return_value=frames(self.client)),contextlib.redirect_stdout(io.StringIO()):out=cycle(self.client,s,self.d,LIVE,False)
  self.assertEqual(out['mode'],'HYBRID_V3_COMPETITION_DRY_RUN');self.assertFalse(out['test_only']);self.assertFalse(self.client.rows)
 def test_overdue_exit_bypasses_public_data(self):
  s=self.actual();s['hybrid_v3']['forced_exit']={'BTCUSDT':{'reason':'CONFIRMED_TREND_EXIT','since_ms':self.client.now-301000}}
  self.client.balance['SpotWallet']['BTC']={'Free':20.,'Lock':0.}
  with patch('quant.hybrid_v3_live_engine.market_frames',side_effect=AssertionError('No public data for overdue exit')),contextlib.redirect_stdout(io.StringIO()):out=cycle(self.client,s,self.d,LIVE,False)
  self.assertTrue(out['orders']);self.assertEqual(out['orders'][0]['type'],'MARKET');self.assertEqual(out['orders'][0]['side'],'SELL')
 def test_migration_preserves_original_recovery_fields(self):
  s={'high_water':110000.,'last_nav':109000.,'confirmed_fills':40,'active_days':['2026-10-04'],'armed_verification':True,'intent':None,'config_hash':'old','old_history':[1,2]}
  before=copy.deepcopy(s);backup=apply_state(self.d,s,LIVE,{'verification':'PASSED_EXECUTION'},109500.)
  self.assertEqual(json.loads(backup.read_text()),before)
  for key in ['high_water','confirmed_fills','active_days','armed_verification','intent','old_history']:self.assertEqual(s[key],before[key])
  self.assertEqual(s['hybrid_v3'],{});self.assertEqual(s['hybrid_v3_mode'],'COMPETITION')
 def test_migration_does_not_reset_risk_breach(self):
  s={'high_water':100000.,'config_hash':'old'}
  with self.assertRaises(Blocked):apply_state(self.d,s,LIVE,{},96000.)
  self.assertFalse((self.d/'state.json').exists())
 def test_apply_is_idempotent(self):
  s=self.actual();before=copy.deepcopy(s)
  self.assertIsNone(apply_state(self.d,s,LIVE,{},50000.));self.assertEqual(s,before)

 def fixture_preflight(self):
  from quant.cross_asset_v2_execution import config_load
  old=config_load('competition.cross_asset_v2.json');a=self.d/'actual';t=self.d/'test';a.mkdir();t.mkdir()
  ap={'api_key':'actual-key','secret':'unused-fixture','account_mode':'COMPETITION'};tp={'api_key':'test-key','secret':'unused-fixture','account_mode':'TEST'}
  ah=hashlib.sha256(ap['api_key'].encode()).hexdigest();th=hashlib.sha256(tp['api_key'].encode()).hexdigest()
  for directory,profile in [(a,ap),(t,tp)]:
   path=directory/'credentials.json';path.write_text(json.dumps(profile));path.chmod(0o600)
  actual={'account_hash':ah,'mode':'COMPETITION','armed_verification':True,'config_hash':digest(old),'intent':None,'high_water':100000.,'last_nav':99999.}
  test={'account_hash':th,'hybrid_v3_mode':'TEST','hybrid_v3_config_hash':digest(TEST),'intent':None}
  proof={'verification':'PASSED_EXECUTION','test_account_hash':th,'candidate_config_hash':digest(TEST),'checks':['maker_fee_0.0005','taker_fee_0.001','known_cancel_terminal','independent_server_query','no_pending','no_short','no_intent'],'confirmed_orders':[{'check':k} for k in ['maker','taker','cancel']],'verified_utc':pd.Timestamp.now(tz='UTC').isoformat()}
  for path,value in [(a/'state.json',actual),(t/'state.json',test),(t/'verification.hybrid_v3.json',proof)]:path.write_text(json.dumps(value))
  return a,t,proof
 def test_preflight_accepts_complete_recent_proof(self):
  a,t,proof=self.fixture_preflight();s,c,p,*_=preflight(a,t)
  self.assertEqual(s['high_water'],100000);self.assertEqual(c,LIVE);self.assertEqual(p,proof)
 def test_preflight_missing_cancel_rejected(self):
  a,t,p=self.fixture_preflight();p['checks'].remove('known_cancel_terminal');(t/'verification.hybrid_v3.json').write_text(json.dumps(p))
  with self.assertRaises(Blocked):preflight(a,t)
 def test_preflight_stale_proof_rejected(self):
  a,t,p=self.fixture_preflight();p['verified_utc']=(pd.Timestamp.now(tz='UTC')-pd.Timedelta('25h')).isoformat();(t/'verification.hybrid_v3.json').write_text(json.dumps(p))
  with self.assertRaises(Blocked):preflight(a,t)
