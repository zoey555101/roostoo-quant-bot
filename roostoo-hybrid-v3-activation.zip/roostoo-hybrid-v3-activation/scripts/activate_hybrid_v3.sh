#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "${1:-}" != --activate || "$PWD" != /home/ssm-user/roostoo-quant-bot || "$(id -un)" != ssm-user ]]; then
 echo 'Explicit activation required: bash scripts/activate_hybrid_v3.sh --activate'
 exit 1
fi
.venv/bin/python -m quant.migrate_hybrid_v3
sudo systemctl stop roostoo-competition
trap 'echo "Activation incomplete; preserve state/intent. Actual service may be stopped. Send the error; do not restore old state."' ERR
.venv/bin/python -m quant.migrate_hybrid_v3 --apply
.venv/bin/python -m quant.hybrid_v3_competition --once
sudo mkdir -p /etc/systemd/system/roostoo-competition.service.d
sudo tee /etc/systemd/system/roostoo-competition.service.d/hybrid_v3.conf >/dev/null <<'UNIT'
[Service]
ExecStart=
ExecStart=/home/ssm-user/roostoo-quant-bot/.venv/bin/python -u -m quant.hybrid_v3_competition --execute
UNIT
sudo systemctl daemon-reload
sudo systemctl start roostoo-competition
sudo systemctl status roostoo-competition --no-pager -l
