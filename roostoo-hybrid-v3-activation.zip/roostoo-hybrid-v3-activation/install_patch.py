"""Add new migration files only. Does not touch state, credentials or services."""
import ast,hashlib,json,os,sys,tempfile
from pathlib import Path
source=Path(__file__).resolve().parent
allowed=['quant/hybrid_v3_probe.py', 'quant/hybrid_v3_live_strategy.py', 'quant/hybrid_v3_live_orders.py', 'quant/hybrid_v3_live_engine.py', 'quant/hybrid_v3_competition.py', 'quant/hybrid_v3_competition_status.py', 'quant/migrate_hybrid_v3.py', 'competition.hybrid_v3.json', 'scripts/activate_hybrid_v3.sh', 'tests/test_hybrid_v3_activation.py']

def main():
 if len(sys.argv)!=2:raise SystemExit('Usage: python3 install_patch.py EXISTING_PROJECT')
 target=Path(sys.argv[1]).expanduser().resolve();m=json.loads((source/'manifest.json').read_text())
 if set(m['new_files'])!=set(allowed):raise SystemExit('Invalid manifest')
 for name,digest in m['dependencies'].items():
  p=target/name
  if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise SystemExit('Dependency differs; nothing installed: '+name)
 for name,digest in m['new_files'].items():
  data=(source/name).read_bytes();dest=target/name
  if hashlib.sha256(data).hexdigest()!=digest:raise SystemExit('Invalid checksum: '+name)
  if name.endswith('.py'):ast.parse(data.decode('utf-8'))
  for p in (dest,*dest.parents):
   if p==target:break
   if p.is_symlink():raise SystemExit('Symlink destination blocked: '+name)
  if dest.exists() and dest.read_bytes()!=data:raise SystemExit('Existing file differs; nothing installed: '+name)
 for name in m['new_files']:
  dest=target/name
  if dest.exists():continue
  dest.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.hybrid-activation-',dir=dest.parent)
  try:
   with os.fdopen(fd,'wb') as f:f.write((source/name).read_bytes())
   os.replace(tmp,dest)
  finally:
   if Path(tmp).exists():Path(tmp).unlink()
 print('Activation files installed. State, credentials and services unchanged.')
if __name__=='__main__':main()
