"""State-preserving V2 -> hybrid migration; offline check by default."""
import argparse,fcntl,hashlib,json,os
from pathlib import Path
import pandas as pd
from .live import Blocked,atomic,audit,pending_check,short_check
from .cross_asset_v2_engine import quote,valuation
from .cross_asset_v2_execution import config_load as v2_config
from .hybrid_v3_strategy import DEFAULTS as TEST_CONFIG
from .hybrid_v3_live_strategy import config_load
from .hybrid_v3_probe import verify_rows
from .roostoo import Roostoo

def digest(c):return hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()

def preflight(directory='runtime/competition',test_directory='runtime/test',candidate='competition.hybrid_v3.json',old_config='competition.cross_asset_v2.json'):
 d=Path(directory);test=Path(test_directory);c=config_load(candidate);old=v2_config(old_config)
 s=json.loads((d/'state.json').read_text());ts=json.loads((test/'state.json').read_text());proof=json.loads((test/'verification.hybrid_v3.json').read_text());tp=json.loads((test/'credentials.json').read_text());ap=json.loads((d/'credentials.json').read_text())
 if ap.get('account_mode')!='COMPETITION' or tp.get('account_mode')!='TEST' or not ap.get('api_key') or not tp.get('api_key') or ap['api_key']==tp['api_key']:raise Blocked('Separate actual and TEST profiles required')
 ah=hashlib.sha256(ap['api_key'].encode()).hexdigest();th=hashlib.sha256(tp['api_key'].encode()).hexdigest()
 if s.get('account_hash')!=ah or s.get('mode')!='COMPETITION' or not s.get('armed_verification'):raise Blocked('Original armed actual recovery state required')
 if s.get('config_hash') not in (digest(old),digest(c)):raise Blocked('Original actual configuration mismatch')
 if s.get('intent') or s.get('halted') or (d/'STOP').exists():raise Blocked('Actual recovery/risk unresolved; do not reset')
 if s.get('high_water',0)<=0 or s.get('last_nav',0)<=0 or s['last_nav']/s['high_water']-1<=-c['drawdown_stop']:raise Blocked('Actual risk exit due; migration blocked')
 checks={'maker_fee_0.0005','taker_fee_0.001','known_cancel_terminal','independent_server_query','no_pending','no_short','no_intent'}
 if ts.get('account_hash')!=th or ts.get('hybrid_v3_mode')!='TEST' or ts.get('hybrid_v3_config_hash')!=digest(TEST_CONFIG):raise Blocked('Registered TEST candidate state required')
 if proof.get('verification')!='PASSED_EXECUTION' or proof.get('test_account_hash')!=th or proof.get('candidate_config_hash')!=digest(TEST_CONFIG) or not checks.issubset(proof.get('checks',[])):raise Blocked('Hybrid execution/cancel proof required')
 if {o.get('check') for o in proof.get('confirmed_orders',[])}!={'maker','taker','cancel'}:raise Blocked('Incomplete maker/taker/cancel proof')
 if ts.get('intent') or ts.get('halted') or (test/'STOP').exists():raise Blocked('Stop/reconcile TEST runner first')
 age=pd.Timestamp.now(tz='UTC')-pd.Timestamp(proof['verified_utc'])
 if age<pd.Timedelta(0) or age>pd.Timedelta('24h'):raise Blocked('Execution proof expired')
 for p in [d/'credentials.json',test/'credentials.json']:
  if p.stat().st_mode&0o077:raise Blocked('Credentials must be 0600')
 return s,c,proof,ap,tp,ts

def apply_state(directory,state,c,proof,nav):
 d=Path(directory)
 if state.get('config_hash')==digest(c):return None
 high=max(float(state['high_water']),nav)
 if nav/high-1<=-c['drawdown_stop']:raise Blocked('Risk exit due; retain original state')
 backup=d/('state.before_hybrid_v3_'+pd.Timestamp.now(tz='UTC').strftime('%Y%m%dT%H%M%S%f')+'.json');atomic(backup,state)
 state.update(config_hash=digest(c),hybrid_v3_config_hash=digest(c),hybrid_v3_mode='COMPETITION',hybrid_v3_verified=proof,high_water=high,last_nav=nav)
 # New signal namespace, not a copy of the TEST positions/exit timers.
 state.setdefault('hybrid_v3',{})
 atomic(d/'state.json',state);audit(d,'hybrid_v3_migration',backup=backup.name,config_hash=digest(c))
 return backup

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--apply',action='store_true');a=p.parse_args()
 s,c,proof,ap,tp,ts=preflight()
 if not a.apply:print('Hybrid migration checks passed. No state/service changes.');return
 locks=Path.home()/'.roostoo-locks'
 # Hold both original bindings while independently re-querying proof and actual account.
 with open(locks/(ts['account_hash']+'.lock'),'a') as test_lock,open(locks/(s['account_hash']+'.lock'),'a') as actual_lock:
  for lock in (test_lock,actual_lock):
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError:raise Blocked('Stop TEST runner and actual service before applying')
  s,c,proof,ap,tp,ts=preflight()
  for directory,st in [('runtime/test',ts),('runtime/competition',s)]:
   bound=locks/(st['account_hash']+'.json')
   if not bound.exists() or json.loads(bound.read_text()).get('state_dir')!=str(Path(directory).resolve()):raise Blocked('Retain original account state directory')
  client=Roostoo()
  for k,env in [('api_key','ROOSTOO_API_KEY'),('secret','ROOSTOO_SECRET_KEY')]:os.environ[env]=tp[k]
  client.sync_time();pending_check(client);short_check(client);verify_rows(client,ts)
  if abs(client.offset)>60000:raise Blocked('TEST clock mismatch')
  valuation(client.request('/v3/balance',{'timestamp':client.timestamp()},True),quote(client),TEST_CONFIG['symbols'])
  for k,env in [('api_key','ROOSTOO_API_KEY'),('secret','ROOSTOO_SECRET_KEY')]:os.environ[env]=ap[k]
  client.sync_time()
  if abs(client.offset)>60000:raise Blocked('Clock mismatch')
  pending_check(client);short_check(client)
  nav=valuation(client.request('/v3/balance',{'timestamp':client.timestamp()},True),quote(client),c['symbols'])
  backup=apply_state('runtime/competition',s,c,proof,nav)
  print('Hybrid migration applied. High water/history retained; service not started. Backup: '+str(backup))
if __name__=='__main__':main()
