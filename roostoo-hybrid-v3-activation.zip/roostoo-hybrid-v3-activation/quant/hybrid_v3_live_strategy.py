"""Pre-registered competition candidate: hysteresis, smoothed targets and ATR protection."""
import copy,json,math
from pathlib import Path
import numpy as np
import pandas as pd
from .live import Blocked,positive,spot_wallet
from .cross_asset_v2_execution import CRYPTO,STOCKS
from .cross_asset_v2_allocator import allocate

DEFAULTS={'strategy_version': 'hybrid_v3_competition', 'start_utc': '2026-10-04T12:00:00Z', 'symbols': ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'LINKUSDT', 'AVAXUSDT', 'LTCUSDT', 'SUIUSDT', 'UNIUSDT', 'AMDBUSDT', 'METABUSDT', 'TSLABUSDT', 'INTCBUSDT', 'GOOGLBUSDT', 'NBISBUSDT', 'LITEBUSDT', 'PLTRBUSDT', 'SPCXBUSDT', 'GLWBUSDT', 'CBRSBUSDT', 'MSFTBUSDT', 'SKHYBUSDT', 'COINBUSDT', 'QCOMBUSDT', 'CRCLBUSDT', 'MUBUSDT', 'NVDABUSDT', 'MSTRBUSDT', 'WDCBUSDT', 'SNDKBUSDT'], 'stock_symbols': ['AMDBUSDT', 'METABUSDT', 'TSLABUSDT', 'INTCBUSDT', 'GOOGLBUSDT', 'NBISBUSDT', 'LITEBUSDT', 'PLTRBUSDT', 'SPCXBUSDT', 'GLWBUSDT', 'CBRSBUSDT', 'MSFTBUSDT', 'SKHYBUSDT', 'COINBUSDT', 'QCOMBUSDT', 'CRCLBUSDT', 'MUBUSDT', 'NVDABUSDT', 'MSTRBUSDT', 'WDCBUSDT', 'SNDKBUSDT'], 'daily_risk_target': 0.005, 'gross_cap': 0.6, 'coin_cap': 0.1, 'stock_cap': 0.3, 'max_order_usd': 5000, 'min_trade_usd': 100, 'test_asset_budget_usd': 1000000000000.0, 'test_gross_budget_usd': 1000000000000.0, 'drawdown_stop': 0.03, 'poll_seconds': 60, 'maker_fee': 0.0005, 'taker_fee': 0.001, 'max_spread': 0.005, 'max_basis': 0.03, 'band_weight': 0.01, 'test_band_usd': 1000000000000.0, 'entry_bars': 2, 'exit_bars': 3, 'atr_bars': 72, 'signal_buffer_atr': 0.25, 'overheat_atr': 3.0, 'stop_atr': 3.0, 'stop_floor': 0.01, 'stop_ceiling': 0.05, 'cooldown_bars': 6, 'weight_alpha': 0.25, 'limit_ttl_seconds': 180, 'exit_deadline_seconds': 300, 'reverse_cooldown_bars': 3, 'opposite_trade_improvement': 0.003, 'max_orders_per_bar': 4, 'max_new_notional_per_bar': 20000, 'normal_turnover_per_hkt_day': 100000, 'config_note': 'Fixed hybrid competition candidate; execution-tested, profitability not validated.', 'risk_exit_poll_seconds': 5}

def config_load(path):
 c=json.loads(Path(path).read_text())
 if c!=DEFAULTS:raise Blocked('Use the registered competition.hybrid_v3.json unchanged')
 return c

def atr(frame,n):
 previous=frame.close.shift(1)
 tr=pd.concat([frame.high-frame.low,(frame.high-previous).abs(),(frame.low-previous).abs()],axis=1).max(axis=1)
 return tr.rolling(n,min_periods=n).mean()

def nav_and_positions(balance,ticker,symbols):
 """Free + Lock is documented inventory; never add PendingOrders a second time."""
 wallet=spot_wallet(balance);values={};units={};nav=0.
 for coin,item in wallet.items():
  if positive(item.get('ShortCollateral',0),'short collateral',True)>1e-8:raise Blocked('Short collateral unsupported')
  # Undocumented reservation representation must not be guessed.
  if positive(item.get('PendingOrders',0),'pending reservation',True)>1e-8:
   raise Blocked('Nonzero PendingOrders wallet field requires schema review; owned intent retained')
  q=positive(item.get('Free',0),'free',True)+positive(item.get('Lock',0),'lock',True)
  if coin=='USD':nav+=q;continue
  symbol=coin+'USDT'
  if q>1e-8 and symbol not in symbols:raise Blocked('Unsupported account inventory')
  if q:
   p=positive(ticker['Data'][coin+'/USD']['LastPrice'],'inventory mark');units[symbol]=q;values[symbol]=q*p;nav+=q*p
 return positive(nav,'NAV'),values,units

def cap_weights(weights,c,nav,frozen=None):
 out={s:max(0.,min(float(v),c['coin_cap'],c['test_asset_budget_usd']/nav)) for s,v in weights.items()}
 frozen=set(frozen or [])
 def reduce_group(keys,cap):
  total=sum(out[s] for s in keys)
  if total<=cap:return
  pinned=[s for s in keys if s in frozen];flex=[s for s in keys if s not in frozen]
  reserved=sum(out[s] for s in pinned);available=max(0,cap-reserved)
  if reserved>cap:
   for s in pinned:out[s]*=cap/reserved
   for s in flex:out[s]=0.
  else:
   flexible=sum(out[s] for s in flex)
   for s in flex:out[s]*=available/flexible if flexible else 0.
 reduce_group([s for s in out if s in c['stock_symbols']],c['stock_cap'])
 reduce_group(list(out),min(c['gross_cap'],c['test_gross_budget_usd']/nav))
 return out

def protective_exits(state,ticker,units,c,now):
 h=state.setdefault('hybrid_v3',{});guards=h.setdefault('guards',{});forced=h.setdefault('forced_exit',{})
 for s,q in units.items():
  if q<=1e-8:continue
  mark=positive(ticker['Data'][s[:-4]+'/USD']['LastPrice'],'risk mark')
  g=guards.get(s)
  if not g:continue
  # One-way stop: a volatility increase cannot loosen an existing stop.
  g['peak']=max(g['peak'],mark);g['stop_price']=max(g['stop_price'],g['peak']*(1-g['stop_fraction']))
  if mark<=g['stop_price']:forced.setdefault(s,{'reason':'ATR_PROTECTIVE_EXIT','since_ms':now})
 return forced

def target_weights(frames,balance,ticker,state,c,now):
 nav,values,units=nav_and_positions(balance,ticker,c['symbols'])
 h=state.setdefault('hybrid_v3',{});guards=h.setdefault('guards',{});forced=h.setdefault('forced_exit',{})
 cooldown=h.setdefault('cooldown_until',{});previous=h.get('targets',{})
 raw,_=allocate(frames,c['stock_symbols'],c['daily_risk_target'],c['gross_cap'],c['coin_cap'],c['stock_cap'],False)
 desired=raw.iloc[-1].to_dict();bar=int(next(iter(frames.values())).index[-1].timestamp()*1000);decisions={};out={}
 for s,f in frames.items():
  close=f.close;fast=close.ewm(span=60,adjust=False,min_periods=150).mean();slow=close.ewm(span=150,adjust=False,min_periods=150).mean()
  mom=close.pct_change(288,fill_method=None);a=atr(f,c['atr_bars']);a_pct=a/close
  liquid=(close*f.volume).rolling(288).sum()>=5000000
  buffer=c['signal_buffer_atr']*a_pct
  gap=(fast-slow)/close
  enter=(mom>buffer)&(gap>buffer)&liquid&(f.volume>0)&((close-fast)/a<=c['overheat_atr'])
  leave=((mom < -buffer)|(gap < -buffer)|(~liquid))&(f.volume>0)
  entry=bool(enter.iloc[-c['entry_bars']:].all());exit_=bool(leave.iloc[-c['exit_bars']:].all())
  owned=units.get(s,0)>1e-8;current=values.get(s,0)/nav
  mark=positive(ticker['Data'][s[:-4]+'/USD']['LastPrice'],'mark')
  if owned:
   fraction=float(np.clip(c['stop_atr']*float(a_pct.iloc[-1]),c['stop_floor'],c['stop_ceiling']))
   if not math.isfinite(fraction):raise Blocked('Invalid ATR protection')
   # Inherited holdings use activation mark, not invented historical cost/high.
   g=guards.setdefault(s,{'peak':mark,'stop_price':mark*(1-fraction),'stop_fraction':fraction,'origin':'activation_or_first_observed_holding'})
   g['stop_fraction']=min(g['stop_fraction'],fraction)
  if owned and exit_:forced.setdefault(s,{'reason':'CONFIRMED_TREND_EXIT','since_ms':now})
  if s in forced:
   weight=0.;reason=forced[s]['reason']
  elif now<cooldown.get(s,0):weight=0. if not owned else current;reason='REENTRY_COOLDOWN'
  elif owned and not entry:weight=current;reason='HOLD_HYSTERESIS'
  elif not entry:weight=0.;reason='NO_CONFIRMED_ENTRY'
  else:
   base=previous.get(s,current);weight=c['weight_alpha']*desired.get(s,0)+(1-c['weight_alpha'])*base;reason='SMOOTHED_TREND_TARGET'
  out[s]=weight
  decisions[s]={'reason':reason,'entry_confirmed':entry,'exit_confirmed':exit_,'momentum_24h':float(mom.iloc[-1]),'ema_gap_fraction':float(gap.iloc[-1]),'atr_fraction':float(a_pct.iloc[-1]),'latest_volume':float(f.volume.iloc[-1]),'raw_target':float(desired.get(s,0))}
 # Frames can exclude non-held invalid quotes; never leave an unsupported target.
 before_caps=dict(out)
 out=cap_weights(out,c,nav,[s for s,d in decisions.items() if d['reason']=='HOLD_HYSTERESIS'])
 for s in out:
  decisions[s]['final_target']=out[s]
  if out[s]<before_caps[s]-1e-12:
   decisions[s]['prior_reason']=decisions[s]['reason'];decisions[s]['reason']='RISK_CAP_REDUCTION'
 h.update(targets=out,decisions=decisions,signal_bar=bar,reference_prices={s:float(f.close.iloc[-1]) for s,f in frames.items()},atr_fractions={s:d['atr_fraction'] for s,d in decisions.items()})
 protective_exits(state,ticker,units,c,now)
 for s in h['forced_exit']:out[s]=0.
 return out,decisions,bar

def finish_exits(state,units,exchange,ticker,c,now):
 h=state.setdefault('hybrid_v3',{});forced=h.setdefault('forced_exit',{})
 for s in list(forced):
  pair=s[:-4]+'/USD';rule=exchange['TradePairs'].get(pair,{})
  # Dust cannot be sold below exchange minimum; retain it in NAV and diagnostics.
  value=units.get(s,0)*positive(ticker['Data'][pair]['MaxBid'],'dust mark')
  if value<=positive(rule.get('MiniOrder',0),'minimum',True):
   h.setdefault('cooldown_until',{})[s]=now+c['cooldown_bars']*300000
   h.setdefault('dust',{})[s]=value
   forced.pop(s);h.setdefault('guards',{}).pop(s,None)
