"""Read local actual state only; no credentials or exchange requests."""
import json
from pathlib import Path
from .hybrid_v3_status import report

def main():
 s=json.loads(Path('runtime/competition/state.json').read_text())
 if s.get('mode')!='COMPETITION' or s.get('hybrid_v3_mode')!='COMPETITION':raise SystemExit('Actual hybrid migration not found')
 out=report(s);out.update(mode='HYBRID_V3_COMPETITION_STATUS',test_only=False,high_water=s.get('high_water'),confirmed_fills=s.get('confirmed_fills'),active_days=s.get('active_days'))
 out['execution_checks']=out.pop('test_checks');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
