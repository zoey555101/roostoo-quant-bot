"""Explicit $20 TEST cancellation probe and independent execution verification."""
import argparse,fcntl,hashlib,json,os
from pathlib import Path
from decimal import Decimal,ROUND_DOWN
import pandas as pd
from .live import Blocked,atomic,positive,quantize,spot_wallet,short_check,audit
from .roostoo import Roostoo
from .cross_asset_v2_test import load_profile
from .cross_asset_v2_engine import quote
from .hybrid_v3_strategy import config_load
from .hybrid_v3_orders import reconcile,pending_guard,submit,cancel

def digest(c):return hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()

def verify_rows(client,state):
 h=state.get('hybrid_v3',{});orders=h.get('completed_orders',[]);selected=[]
 for kind in ('maker','taker','cancel'):
  matches=[o for o in orders if (kind=='maker' and o.get('role')=='MAKER' and o.get('type')=='LIMIT' and o.get('filled_quantity',0)>0) or (kind=='taker' and o.get('role')=='TAKER' and o.get('type')=='MARKET' and o.get('filled_quantity',0)>0) or (kind=='cancel' and o.get('cancel_attempted') and o.get('status') in ('CANCELED','CANCELLED'))]
  if not matches:raise Blocked('Missing live TEST evidence: '+kind)
  item=matches[-1];result=client.request('/v3/query_order',{'timestamp':client.timestamp(),'order_id':str(item['order_id'])},True,'POST')
  rows=[o for o in result.get('OrderMatched',[]) if str(o.get('OrderID'))==str(item['order_id'])]
  if result.get('Success') is not True or len(rows)!=1:raise Blocked('Independent order query failed')
  row=rows[0]
  if any(row.get(field)!=item[key] for field,key in [('Pair','pair'),('Side','side'),('Type','type')]):raise Blocked('Verification order identity mismatch')
  if kind=='cancel':
   if row.get('Status') not in ('CANCELED','CANCELLED'):raise Blocked('Cancellation not terminal on server')
  else:
   if row.get('Status')!='FILLED' or positive(row.get('FilledQuantity',0),'verified filled')<=0:raise Blocked('Fill not confirmed')
   rate=.0005 if kind=='maker' else .001
   if row.get('Role')!=kind.upper() or abs(float(row.get('CommissionPercent',-1))-rate)>1e-10:raise Blocked('Observed fee rate differs from confirmed competition rule')
   quantity=positive(row.get('FilledQuantity'),'verified quantity');price=positive(row.get('FilledAverPrice'),'verified price');fee=positive(row.get('CommissionChargeValue'),'verified fee',True)
   coin=item['pair'].split('/')[0];currency=row.get('CommissionCoin')
   if currency not in ('USD',coin):raise Blocked('Unknown verification fee currency')
   expected=quantity*rate*(price if currency=='USD' else 1.)
   if abs(fee-expected)>max(1.1e-6,expected*1e-5):raise Blocked('Fee amount fails reconciliation')
  selected.append({'check':kind,'order_id':str(item['order_id']),'pair':item['pair'],'side':item['side'],'type':item['type'],'status':row['Status'],'commission_percent':row.get('CommissionPercent')})
 return selected

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute-test',action='store_true');p.add_argument('--verify-only',action='store_true');a=p.parse_args()
 c=config_load('hybrid.v3.test.json');d=Path('runtime/test');profile=load_profile(d/'credentials.json');account=hashlib.sha256(profile['api_key'].encode()).hexdigest();locks=Path.home()/'.roostoo-locks'
 if not (locks/(account+'.json')).exists() or json.loads((locks/(account+'.json')).read_text()).get('state_dir')!=str(d.resolve()):raise SystemExit('Original bound TEST recovery directory required')
 with open(locks/(account+'.lock'),'a') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise SystemExit('Stop the TEST runner with Ctrl+C first; actual service can remain running')
  state=json.loads((d/'state.json').read_text())
  if state.get('account_hash')!=account or state.get('hybrid_v3_mode')!='TEST' or state.get('hybrid_v3_config_hash')!=digest(c):raise Blocked('Registered hybrid TEST state required')
  for k,env in [('api_key','ROOSTOO_API_KEY'),('secret','ROOSTOO_SECRET_KEY')]:os.environ[env]=profile[k]
  os.environ['ROOSTOO_ACCOUNT_MODE']='TEST';client=Roostoo();client.sync_time()
  if abs(client.offset)>60000:raise Blocked('Clock mismatch')
  reconcile(client,state,d);pending_guard(client,state);short_check(client)
  if a.execute_test and state.get('intent'):cancel(client,state,d,True,'PRE_PROBE_CLEANUP')
  if state.get('intent'):raise Blocked('Pending TEST order retained; stop/cancel it explicitly before verification')
  if state.get('halted') or (d/'STOP').exists():raise Blocked('TEST risk unresolved; do not reset it')
  balance=client.request('/v3/balance',{'timestamp':client.timestamp()},True);wallet=spot_wallet(balance)
  if any(float(v.get('Lock',0)) or float(v.get('PendingOrders',0)) or float(v.get('ShortCollateral',0)) for v in wallet.values()):raise Blocked('Reservation unresolved')
  if a.execute_test and not a.verify_only:
   ex=client.request('/v3/exchangeInfo');t=quote(client);pair='BTC/USD';rule=ex['TradePairs'][pair]
   if rule.get('CanTrade') is not True:raise Blocked('BTC probe not tradable')
   precision=int(rule['PricePrecision'])
   if not 0<=precision<=12:raise Blocked('Probe price precision invalid')
   price=Decimal(str(positive(t['Data'][pair]['MaxBid'],'probe bid')*.5)).quantize(Decimal(1).scaleb(-precision),rounding=ROUND_DOWN)
   quantity=quantize(20/float(price),rule['AmountPrecision']);value=float(price*quantity)
   if value<=positive(rule['MiniOrder'],'minimum') or value>20.00001 or value*(1+c['taker_fee'])>positive(wallet['USD']['Free'],'free cash'):raise Blocked('Probe budget insufficient')
   order={'pair':pair,'side':'BUY','quantity':format(quantity,'f'),'type':'LIMIT','price':format(price,'f'),'estimated_notional':value,'reason':'ENGINEERING_CANCEL_PROBE','signal_bar':None}
   audit(d,'hybrid_cancel_probe',maximum_notional=20,price_fraction_of_bid=.5)
   submit(client,state,d,order,c,True)
   if state.get('intent'):cancel(client,state,d,True,'EXPLICIT_CANCEL_PROBE')
   else:print('Probe filled before cancellation; no cancellation proof from this attempt. No retry made.')
  pending_guard(client,state);short_check(client)
  post=spot_wallet(client.request('/v3/balance',{'timestamp':client.timestamp()},True))
  if any(float(v.get('Lock',0)) or float(v.get('PendingOrders',0)) or float(v.get('ShortCollateral',0)) for v in post.values()):raise Blocked('Post-cancel reservations unresolved')
  selected=verify_rows(client,state)
  proof={'verification':'PASSED_EXECUTION','profitability_validated':False,'verified_utc':pd.Timestamp.now(tz='UTC').isoformat(),'test_account_hash':account,'candidate_config_hash':digest(c),'checks':['maker_fee_0.0005','taker_fee_0.001','known_cancel_terminal','independent_server_query','no_pending','no_short','no_intent'],'confirmed_orders':selected}
  atomic(d/'verification.hybrid_v3.json',proof);print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
