"""One durable runner-owned order; no blind submit/cancel retries."""
from decimal import Decimal,ROUND_DOWN,ROUND_UP
from pathlib import Path
import math,os,json,hashlib
import pandas as pd
from .live import Blocked,atomic,audit,positive,spot_wallet,quantize,recover
from .hybrid_v3_live_strategy import nav_and_positions,DEFAULTS

TERMINAL={'FILLED','CANCELED','CANCELLED','REJECTED','EXPIRED'}
OPEN={'PENDING','PARTIALLY_FILLED'}

def save(directory,state):atomic(Path(directory)/'state.json',state)

def assert_test(state,execute):
 expected=hashlib.sha256(json.dumps(DEFAULTS,sort_keys=True).encode()).hexdigest()
 if not execute or os.getenv('ROOSTOO_ACCOUNT_MODE')!='COMPETITION' or state.get('mode')!='COMPETITION' or state.get('hybrid_v3_mode')!='COMPETITION' or not state.get('armed_verification'):
  raise Blocked('Actual hybrid execution requires explicit verified migration')
 if state.get('config_hash')!=expected or state.get('hybrid_v3_config_hash')!=expected or state.get('hybrid_v3_verified',{}).get('verification')!='PASSED_EXECUTION':raise Blocked('Actual execution configuration/proof mismatch')

def query(client,order_id):
 result=client.request('/v3/query_order',{'timestamp':client.timestamp(),'order_id':str(order_id)},True,'POST')
 rows=result.get('OrderMatched');matches=[r for r in rows or [] if str(r.get('OrderID'))==str(order_id)]
 if result.get('Success') is not True or not isinstance(rows,list) or len(matches)!=1:raise Blocked('Owned order query not confirmed; intent retained')
 return matches[0]

def reconcile(client,state,directory):
 intent=state.get('intent')
 if not intent:return None
 if intent.get('owner')!='hybrid_v3':
  recover(client,state,directory);return None
 if intent.get('order_id') is None:raise Blocked('Ambiguous submit retained; inspect exchange history, never reset state or resubmit')
 row=query(client,intent['order_id']);status=row.get('Status')
 if status not in TERMINAL|OPEN:raise Blocked('Unknown order status; intent retained')
 for field,key in [('Pair','pair'),('Side','side'),('Type','type')]:
  if row.get(field)!=intent[key]:raise Blocked('Owned order identity mismatch')
 requested=positive(row.get('Quantity'),'server order quantity')
 if abs(requested-float(intent['quantity']))>max(1e-10,requested*1e-9):raise Blocked('Owned order quantity mismatch')
 filled=positive(row.get('FilledQuantity',0),'filled units',True)
 if filled>requested+1e-8 or filled<float(intent.get('accounted_quantity',0))-1e-8:raise Blocked('Filled quantity inconsistent')
 if status=='FILLED' and abs(filled-requested)>max(1e-8,requested*1e-8):raise Blocked('FILLED quantity incomplete')
 # Roostoo documents PENDING/CANCELED LIMIT rows with requested quantity
 # in FilledQuantity but zero average, inventory/cash changes and commission.
 # Normalize only that fully corroborated no-fill placeholder, never FILLED.
 raw_price=positive(row.get('FilledAverPrice',0),'filled average',True)
 placeholder=(intent['type']=='LIMIT' and status in ('PENDING','CANCELED','CANCELLED')
              and filled>0 and raw_price==0 and float(intent.get('accounted_quantity',0))==0
              and all(k in row and positive(row[k],k,True)==0
                      for k in ('CoinChange','UnitChange','CommissionChargeValue')))
 if placeholder:
  if not intent.get('zero_average_placeholder'):
   audit(directory,'hybrid_no_fill_placeholder',order_id=intent['order_id'],reported_quantity=filled,status=status)
  intent['zero_average_placeholder']=True
  filled=0.
 price=positive(raw_price,'filled average',filled==0)
 cumulative_notional=filled*price
 fee=positive(row.get('CommissionChargeValue',0),'commission',True)
 fee_coin=row.get('CommissionCoin','USD');coin=intent['pair'].split('/')[0]
 if fee and fee_coin not in ('USD',coin):raise Blocked('Unknown commission currency')
 if intent.get('accounted_fee_coin') not in (None,fee_coin):raise Blocked('Commission currency changed')
 # Store native cumulative fee; convert only its increment at current fill price.
 previous_fee=float(intent.get('accounted_fee_native',0));previous_notional=float(intent.get('accounted_notional',0))
 if fee<previous_fee-1e-10 or cumulative_notional<previous_notional-1e-8:raise Blocked('Cumulative order amounts moved backwards')
 dq=filled-float(intent.get('accounted_quantity',0));dn=cumulative_notional-previous_notional;df=fee-previous_fee
 h=state.setdefault('hybrid_v3',{})
 if dq>1e-10 or df>1e-10:
  if dq<=1e-10 and dn>1e-8:raise Blocked('Notional increased without fill quantity')
  fee_usd=df*(price if fee_coin==coin else 1.)
  h['fees_usd']=h.get('fees_usd',0)+fee_usd;h['filled_notional']=h.get('filled_notional',0)+dn
  day=pd.to_datetime(int(row.get('FinishTimestamp') or client.timestamp()),unit='ms',utc=True).tz_convert('Asia/Hong_Kong').strftime('%Y-%m-%d')
  h.setdefault('daily_turnover',{})[day]=h.setdefault('daily_turnover',{}).get(day,0)+dn
  record={'order_id':str(intent['order_id']),'pair':intent['pair'],'side':intent['side'],'type':intent['type'],'quantity_delta':dq,'notional_delta':dn,'fee_usd':fee_usd,'fee_native':df,'commission_coin':fee_coin,'commission_percent':row.get('CommissionPercent'),'role':row.get('Role'),'status':status,'reason':intent['reason'],'observed_ms':int(client.timestamp())}
  h.setdefault('fills',[]).append(record)
  # Persistent records are authoritative; JSONL is a human-readable projection.
  h.setdefault('last_trade',{})[coin+'USDT']={'side':intent['side'],'price':price,'ms':int(client.timestamp())}
  state['active_days']=sorted(set(state.get('active_days',[]))|{day})
  intent.update(accounted_quantity=filled,accounted_notional=cumulative_notional,accounted_fee_native=fee,accounted_fee_coin=fee_coin)
  save(directory,state);audit(directory,'hybrid_fill',**record)
 intent.update(status=status,remaining_quantity=max(0,requested-filled))
 if status in TERMINAL:
  if filled>0:state['confirmed_fills']=int(state.get('confirmed_fills',0))+1
  h.setdefault('completed_orders',[]).append({'order_id':str(intent['order_id']),'pair':intent['pair'],'side':intent['side'],'type':intent['type'],'status':status,'filled_quantity':filled,'fee_native':fee,'fee_coin':fee_coin,'commission_percent':row.get('CommissionPercent'),'role':row.get('Role'),'reason':intent['reason'],'cancel_attempted':intent.get('cancel_attempted',False)})
  state['intent']=None
 save(directory,state)
 return row

def pending_guard(client,state):
 result=client.request('/v3/query_order',{'timestamp':client.timestamp(),'pending_only':'TRUE','limit':'100'},True,'POST',True)
 empty=result.get('Success') is False and ' '.join(str(result.get('ErrMsg','')).split()).casefold().rstrip('.')=='no order matched'
 if empty:rows=[]
 elif result.get('Success') is True and isinstance(result.get('OrderMatched'),list):rows=result['OrderMatched']
 else:raise Blocked('Pending-order list not confirmed')
 if len(rows)>=100:raise Blocked('Pending list may be truncated')
 intent=state.get('intent');owned=str(intent.get('order_id')) if intent and intent.get('owner')=='hybrid_v3' else None
 if any(str(r.get('OrderID'))!=owned for r in rows):raise Blocked('External pending order exists; never cancel orders not owned by this runner')
 if owned and len(rows)>1:raise Blocked('Multiple pending orders inconsistent')
 return rows

def cancel(client,state,directory,execute,reason):
 assert_test(state,execute);intent=state.get('intent')
 if not intent or intent.get('owner')!='hybrid_v3' or intent.get('order_id') is None:raise Blocked('No confirmed owned cancellation target')
 row=reconcile(client,state,directory)
 if not state.get('intent'):return
 if intent.get('cancel_attempted'):raise Blocked('Cancellation remains unconfirmed; query only, no repeated cancel POST')
 intent['cancel_attempted']=True;intent['cancel_reason']=reason;save(directory,state)
 audit(directory,'hybrid_cancel_intent',order_id=intent['order_id'],reason=reason)
 # Query again even on cancellation transport error: no new order before terminal.
 try:client.request('/v3/cancel_order',{'timestamp':client.timestamp(),'order_id':str(intent['order_id'])},True,'POST')
 except Exception:
  reconcile(client,state,directory)
  if state.get('intent'):raise Blocked('Cancellation outcome unresolved; owned intent retained')
  return
 reconcile(client,state,directory)
 if state.get('intent'):raise Blocked('Cancellation not terminal; no replacement allowed')


def submit(client,state,directory,order,c,execute):
 assert_test(state,execute)
 if state.get('intent'):raise Blocked('One owned order at a time')
 if order['side']=='BUY' and state.get('halted'):raise Blocked('Account permits risk sells only')
 now=int(client.timestamp())
 if now<int(pd.Timestamp(c['start_utc']).timestamp()*1000):raise Blocked('Start gate closed')
 if positive(order['estimated_notional'],'order notional')>c['max_order_usd']+1e-7:raise Blocked('Actual order slice exceeded')
 quantity=positive(order['quantity'],'order quantity')
 if order['type'] not in ('LIMIT','MARKET') or order['side'] not in ('BUY','SELL'):raise Blocked('Invalid order kind')
 if order['type']=='LIMIT' and abs(quantity*positive(order['price'],'limit price')-order['estimated_notional'])>1e-6:raise Blocked('Limit amount mismatch')
 intent={**order,'owner':'hybrid_v3','order_id':None,'submitted_ms':now,'accounted_quantity':0.,'accounted_notional':0.,'accounted_fee_native':0.}
 state['intent']=intent;save(directory,state);audit(directory,'hybrid_submit_intent',**intent)
 params={k:order[k] for k in ('pair','side','quantity','type')};params['timestamp']=str(now)
 if order['type']=='LIMIT':params['price']=order['price']
 result=client.request('/v3/place_order',params,True,'POST')
 detail=result.get('OrderDetail',{})
 if result.get('Success') is not True or detail.get('OrderID') is None:raise Blocked('Submit not confirmed; do not retry or clear intent')
 intent['order_id']=detail['OrderID'];save(directory,state)
 return reconcile(client,state,directory)

def passive_price(side,bid,ask,precision):
 precision=int(precision)
 if not 0<=precision<=12:raise Blocked('Unsupported price precision')
 tick=Decimal(1).scaleb(-precision)
 p=Decimal(str(bid if side=='BUY' else ask)).quantize(tick,rounding=ROUND_DOWN if side=='BUY' else ROUND_UP)
 if p<=0 or (side=='BUY' and p>=Decimal(str(ask))) or (side=='SELL' and p<=Decimal(str(bid))):raise Blocked('Cannot construct passive limit price')
 return format(p,'f')

def plan_orders(exchange,ticker,balance,weights,state,c,now):
 if exchange.get('IsRunning') is not True:raise Blocked('Exchange stopped')
 wallet=spot_wallet(balance);nav,values,units=nav_and_positions(balance,ticker,c['symbols']);h=state.setdefault('hybrid_v3',{});forced=h.get('forced_exit',{});orders=[]
 cash=positive(wallet['USD'].get('Free',0),'free cash',True)
 gross=sum(values.values());stocks=sum(values.get(s,0) for s in c['stock_symbols'])
 day=pd.to_datetime(now,unit='ms',utc=True).tz_convert('Asia/Hong_Kong').strftime('%Y-%m-%d')
 daily=h.get('daily_turnover',{}).get(day,0);normal_budget=max(0,c['normal_turnover_per_hkt_day']-daily)
 for s in c['symbols']:
  pair=s[:-4]+'/USD';rule=exchange.get('TradePairs',{}).get(pair);quote=ticker.get('Data',{}).get(pair)
  held=units.get(s,0);risk=bool(state.get('halted') or (s in forced and forced[s]['reason']=='ATR_PROTECTIVE_EXIT'))
  exit_=bool(state.get('halted') or s in forced)
  weight=0. if exit_ else float(weights.get(s,0))
  if not rule or not quote:
   if held>1e-8:raise Blocked('Held quote missing')
   continue
  if rule.get('CanTrade') is not True:
   if held>1e-8:raise Blocked('Held asset not tradable')
   continue
  bid=positive(quote['MaxBid'],'bid');ask=positive(quote['MinAsk'],'ask');mark=positive(quote['LastPrice'],'mark')
  if ask<bid:raise Blocked('Crossed quote')
  delta=weight*nav-values.get(s,0)
  hard_target=min(c['coin_cap']*nav,c['test_asset_budget_usd'])
  if gross>min(c['gross_cap']*nav,c['test_gross_budget_usd']):hard_target=min(hard_target,values.get(s,0)*min(c['gross_cap']*nav,c['test_gross_budget_usd'])/gross)
  if s in c['stock_symbols'] and stocks>c['stock_cap']*nav:hard_target=min(hard_target,values.get(s,0)*c['stock_cap']*nav/stocks)
  cap_reduction=values.get(s,0)>hard_target+c['min_trade_usd']
  if cap_reduction:delta=min(delta,hard_target-values.get(s,0))
  if abs(delta)<=1e-8:continue
  side='BUY' if delta>0 else 'SELL'
  if side=='BUY' and (state.get('halted') or forced or exit_):continue
  if not risk and (ask-bid)/((ask+bid)/2)>c['max_spread']:continue
  reference=h.get('reference_prices',{}).get(s)
  if not risk and reference and abs(mark/reference-1)>c['max_basis']:continue
  band=max(c['min_trade_usd'],min(nav*c['band_weight'],c['test_band_usd']))
  if not exit_ and abs(delta)<band:continue
  reason='PORTFOLIO_RISK_EXIT' if state.get('halted') else forced.get(s,{}).get('reason','EXPOSURE_CAP_REDUCTION' if cap_reduction else 'TARGET_REBALANCE')
  deadline=exit_ and now-forced.get(s,{}).get('since_ms',now)>=c['exit_deadline_seconds']*1000
  kind='MARKET' if risk or deadline else 'LIMIT'
  if kind=='LIMIT':price_text=passive_price(side,bid,ask,rule['PricePrecision']);price=float(price_text)
  else:price=ask if side=='BUY' else bid;price_text=None
  # Opposite ordinary trading requires time AND favourable price movement;
  # signal/risk exits bypass this economic filter.
  last=h.get('last_trade',{}).get(s)
  if not exit_ and not cap_reduction and last and side!=last['side']:
   if now-last['ms']<c['reverse_cooldown_bars']*300000:continue
   favourable=(price/last['price']-1) if side=='SELL' else (last['price']/price-1)
   if favourable<c['opposite_trade_improvement']:continue
  budget=c['max_order_usd'] if exit_ or cap_reduction else min(c['max_order_usd'],normal_budget)
  notional=min(abs(delta),budget)
  if side=='BUY':
   safe_cap=min(c['gross_cap']*nav,c['test_gross_budget_usd'])
   notional=min(notional,max(0,cash-(1-c['gross_cap'])*nav)/(1+c['taker_fee']),max(0,safe_cap-gross)/(1+c['taker_fee']),max(0,min(c['coin_cap']*nav,c['test_asset_budget_usd'])-values.get(s,0))/(1+c['taker_fee']))
   if s in c['stock_symbols']:notional=min(notional,max(0,c['stock_cap']*nav-stocks)/(1+c['taker_fee']))
  free=positive(wallet.get(s[:-4],{}).get('Free',0),'available units',True)
  quantity=quantize(min(free,notional/price) if side=='SELL' else notional/price,rule['AmountPrecision'])
  value=float(quantity)*price
  minimum=positive(rule['MiniOrder'],'minimum',True)
  if quantity<=0 or value<=minimum or (not exit_ and value<c['min_trade_usd']):continue
  order={'pair':pair,'side':side,'quantity':format(quantity,'f'),'type':kind,'estimated_notional':value,'reason':reason,'signal_bar':h.get('signal_bar')}
  if price_text is not None:order['price']=price_text
  orders.append(order)
 # Prioritize risks, then oldest normal asset to prevent serial-order starvation.
 orders.sort(key=lambda o:(0 if o['type']=='MARKET' and o['side']=='SELL' else 1 if o['side']=='SELL' else 2,h.get('last_submit',{}).get(o['pair'],0),-o['estimated_notional']))
 return nav,orders
