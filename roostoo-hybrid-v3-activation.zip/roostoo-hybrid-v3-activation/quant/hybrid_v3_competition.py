"""Actual hybrid runner. Read-only by default; verified migration required."""
import argparse,fcntl,hashlib,json,os,time
from pathlib import Path
from .live import Blocked,audit
from .roostoo import Roostoo
from .hybrid_v3_live_strategy import config_load
from .hybrid_v3_live_engine import cycle
from .migrate_hybrid_v3 import digest

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--once',action='store_true');a=p.parse_args();c=config_load('competition.hybrid_v3.json');d=Path('runtime/competition');path=d/'credentials.json'
 if path.stat().st_mode&0o077:raise SystemExit('Actual credentials must be 0600')
 profile=json.loads(path.read_text());test=json.loads(Path('runtime/test/credentials.json').read_text())
 if profile.get('account_mode')!='COMPETITION' or not profile.get('api_key') or not profile.get('secret') or profile['api_key']==test.get('api_key'):raise SystemExit('Separate actual credentials required')
 for k,env in [('api_key','ROOSTOO_API_KEY'),('secret','ROOSTOO_SECRET_KEY')]:os.environ[env]=profile[k]
 os.environ['ROOSTOO_ACCOUNT_MODE']='COMPETITION';os.umask(0o077);account=hashlib.sha256(profile['api_key'].encode()).hexdigest();locks=Path.home()/'.roostoo-locks';bound=locks/(account+'.json')
 if not bound.exists() or json.loads(bound.read_text()).get('state_dir')!=str(d.resolve()):raise SystemExit('Original actual recovery binding required')
 with open(locks/(account+'.lock'),'a') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise SystemExit('Another actual runner holds account lock')
  s=json.loads((d/'state.json').read_text())
  if s.get('account_hash')!=account or s.get('mode')!='COMPETITION' or s.get('hybrid_v3_mode')!='COMPETITION' or s.get('config_hash')!=digest(c) or s.get('hybrid_v3_verified',{}).get('verification')!='PASSED_EXECUTION':raise SystemExit('Verified explicit hybrid migration required')
  client=Roostoo()
  try:
   while True:
    cycle(client,s,d,c,a.execute)
    if a.once:return
    # Faster subsequent slices only during risk/overdue trend exits. Normal
    # entries and signal assessment remain on closed five-minute candles.
    forced=s.get('hybrid_v3',{}).get('forced_exit',{})
    fast=s.get('halted') or any(v['reason']=='ATR_PROTECTIVE_EXIT' or int(client.timestamp())-v['since_ms']>=c['exit_deadline_seconds']*1000 for v in forced.values())
    time.sleep(c['risk_exit_poll_seconds'] if fast else c['poll_seconds'])
  except KeyboardInterrupt:return
  except Exception as e:
   audit(d,'hybrid_actual_stopped',error_type=type(e).__name__,has_intent=bool(s.get('intent')))
   raise SystemExit('Stopped safely: '+(str(e) if isinstance(e,Blocked) else type(e).__name__))
if __name__=='__main__':main()
