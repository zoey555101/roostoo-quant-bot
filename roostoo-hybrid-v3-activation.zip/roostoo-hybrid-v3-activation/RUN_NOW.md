# 现在完成测试并切换

不要求等到明早。需要的条件是服务端真实成交/手续费、撤单终态以及账户恢复核对通过。

1. 将 roostoo-hybrid-v3-activation.zip 原样上传到 GitHub 仓库 master 根目录。AWS 安装命令见单独的 AWS_HYBRID_ACTIVATE.txt；不使用长 Base64 文本。
2. 回到 TEST 窗口：tmux attach -t roostoo-hybrid-test，然后按 Ctrl+C 停止 TEST runner。不要删除 runtime 或 intent；此时原正式服务可以继续运行。若 tmux 名称不同先用 tmux ls 找到原测试会话，勿新建第二个执行进程。
3. 在项目目录运行 .venv/bin/python -m quant.hybrid_v3_probe --execute-test。此命令明确用 TEST 凭证提交最高 $20 BTC 限价单（买价为当前 bid 的一半），立即尝试撤销自己的已知订单。单子仍有成交可能；只以独立查询的服务端终态为准，不会自动反复试单。核对原 maker 0.05%、taker 0.1% 与撤单后挂单/余额保留/short 均清楚，再保存 PASSED_EXECUTION。
4. 只有输出 PASSED_EXECUTION 后，运行 .venv/bin/python -m quant.migrate_hybrid_v3，再运行 bash scripts/activate_hybrid_v3.sh --activate。脚本先检查，再停止旧正式服务，锁定两账户，重新查询测试证据与正式余额，然后备份/迁移、只读检查并启动原 systemd 服务的新模块。任何异常保留恢复状态；不要手工恢复旧 state 或删 intent。
5. sudo journalctl -u roostoo-competition -n 15 --no-pager，应看到 HYBRID_V3_COMPETITION_EXECUTE。正式本地状态：.venv/bin/python -m quant.hybrid_v3_competition_status。查看挂单、费用、退出原因和服务状态。

## 固定实际参数

候选宇宙12种加密币和21种股票代币，按健康行情、流动性、趋势和波动风险动态筛选与分配；不是普通券商股票账户。总暴露上限60%，单标的10%，股票代币合计30%；上限不是固定仓位。继承现有持仓，首次保护价从启用时行情建立，不虚构此前的持仓峰值；原组合高水位和3%永久退出锁保留。

5分钟已收盘信号：入场2根确认、退出3根确认、ATR保护、过热不追价、目标平滑、反向交易价格改善/冷却。5分钟只是决策粒度，不承诺每5分钟交易。正常订单限价优先；3分钟未成交撤单终态确认后重新评估；趋势退出满5分钟或风险退出用市价。一个已知挂单未解决前不会提交下一个。风险退出不等待正常5分钟信号或公共行情下载。

正式单笔最高$5,000、最小$100、普通每根最多4单/合计$20,000、每日普通成交金额上限$100,000；退出不受普通成交预算约束。正常偏离带为1%净值。常态60秒轮询；已进入风险/超时退出后5秒继续处理后续切片，另加网络耗时；不是硬实时保证。大订单本身不会降低按比例手续费，节省来自 maker 成交及减少不必要换手。

本次是工程迁移，非最优仓位或盈利证明。TEST 执行规模不同于正式规模；真实正式成交延迟和盈利尚未验证。没有重新运行历史收益研究，没有连接用户 AWS 或替用户下单。

## 验证

209项项目测试通过；新增16项覆盖服务端 maker/taker/cancel 独立确认、费用错误拒绝、缺失/过期证据拒绝、TEST/actual隔离、正式切片、只读无下单、超时退出不依赖公共数据、高水位与历史保留及迁移幂等。编译、shell语法及CLI帮助检查通过。安装器通过隔离副本检查仅新增白名单文件；依赖不符时拒绝写入。旧 TEST 模块及正式 V2、凭证、配置与 runtime 均不覆盖。
